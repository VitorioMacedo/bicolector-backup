-- Executado de forma idempotente na inicialização da aplicação (app/db/schema.py), depois que as tabelas base
-- foram criadas pelo SQLAlchemy. Cada comando é separado por uma linha com o marcador de dois arrobas e roda
-- como um batch próprio (CREATE OR ALTER VIEW precisa ser o primeiro comando do batch).
-- Também pode ser aplicado manualmente com o sqlcmd, trocando as linhas do marcador por GO.
--
-- Horários: todas as colunas de tempo (ts, bucket) são DATETIME2 em UTC. As views v_pbi_* convertem para o fuso
-- de display_timezone_windows (gravado pela aplicação a partir da configuração display_timezone).

-- Colunas acrescentadas depois da primeira versão (create_all não altera tabelas existentes).
IF COL_LENGTH('gateway', 'color') IS NULL ALTER TABLE gateway ADD color VARCHAR(7) NULL;
-- @@
-- ===== Tabelas de leitura: chave agrupada por medidor e tempo, duplicatas ignoradas, compressão de página =====
-- IGNORE_DUP_KEY: o gravador reenvia o lote inteiro se a conexão cair no meio; a linha repetida é descartada
-- em silêncio em vez de derrubar o lote. A compressão de página reduz ~70 % o espaço das leituras de 1 s.
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'pk_reading_fast')
BEGIN
  DECLARE @pk sysname = (SELECT name FROM sys.key_constraints WHERE parent_object_id = OBJECT_ID('reading_fast') AND type = 'PK');
  IF @pk IS NOT NULL EXEC('ALTER TABLE reading_fast DROP CONSTRAINT [' + @pk + ']');
  ALTER TABLE reading_fast ADD CONSTRAINT pk_reading_fast PRIMARY KEY CLUSTERED (meter_id, ts) WITH (IGNORE_DUP_KEY = ON, DATA_COMPRESSION = PAGE);
END
-- @@
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'pk_reading_slow')
BEGIN
  DECLARE @pk sysname = (SELECT name FROM sys.key_constraints WHERE parent_object_id = OBJECT_ID('reading_slow') AND type = 'PK');
  IF @pk IS NOT NULL EXEC('ALTER TABLE reading_slow DROP CONSTRAINT [' + @pk + ']');
  ALTER TABLE reading_slow ADD CONSTRAINT pk_reading_slow PRIMARY KEY CLUSTERED (meter_id, ts) WITH (IGNORE_DUP_KEY = ON, DATA_COMPRESSION = PAGE);
END
-- @@
IF NOT EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'pk_poll_cycle')
BEGIN
  DECLARE @pk sysname = (SELECT name FROM sys.key_constraints WHERE parent_object_id = OBJECT_ID('poll_cycle') AND type = 'PK');
  IF @pk IS NOT NULL EXEC('ALTER TABLE poll_cycle DROP CONSTRAINT [' + @pk + ']');
  ALTER TABLE poll_cycle ADD CONSTRAINT pk_poll_cycle PRIMARY KEY CLUSTERED (gateway_id, ts) WITH (IGNORE_DUP_KEY = ON, DATA_COMPRESSION = PAGE);
END
-- @@
-- Índices por tempo: retenção (DELETE ... WHERE ts < x), MIN(ts) do primeiro rollup e consultas por período.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_reading_fast_ts') CREATE INDEX ix_reading_fast_ts ON reading_fast (ts) WITH (DATA_COMPRESSION = PAGE);
-- @@
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_reading_slow_ts') CREATE INDEX ix_reading_slow_ts ON reading_slow (ts) WITH (DATA_COMPRESSION = PAGE);
-- @@
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_poll_cycle_ts') CREATE INDEX ix_poll_cycle_ts ON poll_cycle (ts);
-- @@
-- ===== Agregados (tabelas de resumo preenchidas pela aplicação, app/db/rollup.py, a cada minuto) =====
-- agg_state guarda, por tabela, o início do bucket ainda incompleto (watermark): buckets anteriores estão
-- materializados; o que vem depois é calculado na hora a partir das tabelas brutas pelas consultas do painel.
IF OBJECT_ID('agg_state', 'U') IS NULL
CREATE TABLE agg_state (name VARCHAR(40) NOT NULL PRIMARY KEY, watermark DATETIME2(0) NOT NULL, updated_at DATETIME2(0) NOT NULL);
-- @@
IF OBJECT_ID('agg_1min', 'U') IS NULL
CREATE TABLE agg_1min (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  p_avg FLOAT NULL, p_min FLOAT NULL, p_max FLOAT NULL, q_avg FLOAT NULL, s_avg FLOAT NULL,
  i_avg FLOAT NULL, i_max FLOAT NULL, ia_avg FLOAT NULL, ib_avg FLOAT NULL, ic_avg FLOAT NULL,
  vln_avg FLOAT NULL, vln_min FLOAT NULL, vln_max FLOAT NULL, vll_avg FLOAT NULL,
  pf_avg FLOAT NULL, pf_min FLOAT NULL, samples INT NOT NULL,
  CONSTRAINT pk_agg_1min PRIMARY KEY CLUSTERED (meter_id, bucket) WITH (DATA_COMPRESSION = PAGE));
-- @@
IF OBJECT_ID('agg_15min', 'U') IS NULL
CREATE TABLE agg_15min (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  p_avg FLOAT NULL, p_min FLOAT NULL, p_max FLOAT NULL, q_avg FLOAT NULL, s_avg FLOAT NULL,
  i_avg FLOAT NULL, i_max FLOAT NULL, vln_avg FLOAT NULL, vln_min FLOAT NULL, vln_max FLOAT NULL,
  pf_avg FLOAT NULL, pf_min FLOAT NULL, samples INT NOT NULL,
  CONSTRAINT pk_agg_15min PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
IF OBJECT_ID('agg_1h', 'U') IS NULL
CREATE TABLE agg_1h (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  p_avg FLOAT NULL, p_min FLOAT NULL, p_max FLOAT NULL, q_avg FLOAT NULL, s_avg FLOAT NULL,
  i_avg FLOAT NULL, i_max FLOAT NULL, vln_avg FLOAT NULL, vln_min FLOAT NULL, vln_max FLOAT NULL,
  pf_avg FLOAT NULL, pf_min FLOAT NULL, samples INT NOT NULL,
  CONSTRAINT pk_agg_1h PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
IF OBJECT_ID('agg_1d', 'U') IS NULL
CREATE TABLE agg_1d (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  p_avg FLOAT NULL, p_min FLOAT NULL, p_max FLOAT NULL,
  i_avg FLOAT NULL, i_max FLOAT NULL, vln_avg FLOAT NULL, vln_min FLOAT NULL, vln_max FLOAT NULL,
  pf_avg FLOAT NULL, pf_min FLOAT NULL, samples INT NOT NULL,
  CONSTRAINT pk_agg_1d PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
-- Energia: kwh_consumed = último - primeiro acumulador dentro do bucket (as views e o painel usam a diferença
-- entre buckets consecutivos, que não perde o salto entre um bucket e o seguinte).
IF OBJECT_ID('agg_energy_1h', 'U') IS NULL
CREATE TABLE agg_energy_1h (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  kwh_first FLOAT NULL, kwh_last FLOAT NULL, kwh_consumed FLOAT NULL, kwh_exported FLOAT NULL, kvarh_consumed FLOAT NULL,
  demand_peak FLOAT NULL, freq_avg FLOAT NULL,
  thd_ia FLOAT NULL, thd_ib FLOAT NULL, thd_ic FLOAT NULL, thd_van FLOAT NULL, thd_vbn FLOAT NULL, thd_vcn FLOAT NULL,
  CONSTRAINT pk_agg_energy_1h PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
IF OBJECT_ID('agg_energy_1d', 'U') IS NULL
CREATE TABLE agg_energy_1d (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  kwh_first FLOAT NULL, kwh_last FLOAT NULL, kwh_consumed FLOAT NULL, kwh_exported FLOAT NULL, demand_peak FLOAT NULL,
  CONSTRAINT pk_agg_energy_1d PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
-- Todas as grandezas rápidas por minuto e lentas por hora: base do gráfico por grandeza do painel.
IF OBJECT_ID('agg_fast_1min', 'U') IS NULL
CREATE TABLE agg_fast_1min (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  ia FLOAT NULL, ib FLOAT NULL, ic FLOAT NULL, in_ FLOAT NULL, i_avg FLOAT NULL,
  vab FLOAT NULL, vbc FLOAT NULL, vca FLOAT NULL, vll_avg FLOAT NULL,
  van FLOAT NULL, vbn FLOAT NULL, vcn FLOAT NULL, vln_avg FLOAT NULL,
  p_a FLOAT NULL, p_b FLOAT NULL, p_c FLOAT NULL, p_total FLOAT NULL, q_total FLOAT NULL, s_total FLOAT NULL,
  pf_total FLOAT NULL, pf_disp FLOAT NULL, samples INT NOT NULL,
  CONSTRAINT pk_agg_fast_1min PRIMARY KEY CLUSTERED (meter_id, bucket) WITH (DATA_COMPRESSION = PAGE));
-- @@
IF OBJECT_ID('agg_slow_1h', 'U') IS NULL
CREATE TABLE agg_slow_1h (
  bucket DATETIME2(0) NOT NULL, meter_id INT NOT NULL,
  freq FLOAT NULL, demand_present FLOAT NULL, demand_last FLOAT NULL, demand_peak FLOAT NULL, demand_peak_max FLOAT NULL,
  kwh_import FLOAT NULL, kwh_export FLOAT NULL, kwh_net FLOAT NULL, kvarh FLOAT NULL, kvah FLOAT NULL,
  thd_ia FLOAT NULL, thd_ib FLOAT NULL, thd_ic FLOAT NULL, thd_van FLOAT NULL, thd_vbn FLOAT NULL, thd_vcn FLOAT NULL,
  samples INT NOT NULL,
  CONSTRAINT pk_agg_slow_1h PRIMARY KEY CLUSTERED (meter_id, bucket));
-- @@
-- ===== Views de apoio =====
CREATE OR ALTER VIEW v_meter AS
SELECT m.id AS meter_id, m.name AS machine, m.unit_id, m.enabled, g.id AS gateway_id, g.name AS gateway,
       g.color AS gateway_color
FROM meter m JOIN gateway g ON g.id = m.gateway_id;
-- @@
CREATE OR ALTER VIEW v_meter_latest AS
SELECT v.meter_id, v.machine, v.gateway, f.ts, f.p_total, f.q_total, f.s_total, f.pf_total,
       f.ia, f.ib, f.ic, f.i_avg, f.van, f.vbn, f.vcn, f.vln_avg, f.vll_avg,
       s.ts AS slow_ts, s.kwh_import, s.kwh_export, s.freq, s.demand_present, s.demand_peak
FROM v_meter v
OUTER APPLY (SELECT TOP (1) * FROM reading_fast r WHERE r.meter_id = v.meter_id AND r.ts > DATEADD(minute, -10, SYSUTCDATETIME()) ORDER BY r.ts DESC) f
OUTER APPLY (SELECT TOP (1) * FROM reading_slow r WHERE r.meter_id = v.meter_id AND r.ts > DATEADD(hour, -1, SYSUTCDATETIME()) ORDER BY r.ts DESC) s;
-- @@
-- Depois de um reset o acumulador resetável recomeça em zero, então o kWh atual É o consumo desde o reset.
CREATE OR ALTER VIEW v_energy_since_reset AS
SELECT v.meter_id, v.machine,
       (SELECT MAX(ts) FROM command_log c WHERE c.meter_id = v.meter_id AND c.command = 'reset_energy' AND c.success = 1) AS last_reset_at,
       s.kwh_import AS kwh_since_reset, s.ts AS as_of
FROM v_meter v
OUTER APPLY (SELECT TOP (1) * FROM reading_slow r WHERE r.meter_id = v.meter_id ORDER BY r.ts DESC) s;
-- @@
CREATE OR ALTER VIEW v_poll_health AS
SELECT g.id AS gateway_id, g.name AS gateway, DATEADD(minute, DATEDIFF(minute, '2000-01-01', p.ts), '2000-01-01') AS bucket,
       AVG(CAST(p.duration_ms AS FLOAT)) AS duration_avg_ms, MAX(p.duration_ms) AS duration_max_ms,
       MAX(p.interval_ms) AS interval_ms, SUM(p.meters_failed) AS failures, COUNT(*) AS cycles
FROM poll_cycle p JOIN gateway g ON g.id = p.gateway_id
GROUP BY g.id, g.name, DATEADD(minute, DATEDIFF(minute, '2000-01-01', p.ts), '2000-01-01');
-- @@
-- ===== Views para o Power BI (relatório powerbi/bic.pbip) =====
-- Fuso das views: nome de fuso do Windows gravado pela aplicação (Configurações -> Fuso horário).
CREATE OR ALTER VIEW v_bic_tz AS
SELECT COALESCE((SELECT TOP (1) CAST(value AS NVARCHAR(128)) FROM app_setting WHERE [key] = 'display_timezone_windows'), 'Central Brazilian Standard Time') AS tz;
-- @@
CREATE OR ALTER VIEW v_pbi_1min AS
SELECT CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS bucket_local, a.bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, q_avg, s_avg, i_avg, i_max, ia_avg, ib_avg, ic_avg, vln_avg, vln_min, vln_max, vll_avg, pf_avg, pf_min, samples,
       CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS dia_local
FROM agg_1min a JOIN meter m ON m.id = a.meter_id CROSS JOIN v_bic_tz z
WHERE a.bucket > DATEADD(day, -7, SYSUTCDATETIME());
-- @@
-- Últimos 7 dias em buckets de 5 min: consumo (último kwh_import do bucket em reading_slow, diferença entre buckets,
-- reset-safe) + grandezas rápidas de agg_1min (médias ponderadas pelas amostras). É a resolução do ranking do painel
-- em períodos de até 7 dias; o bucket extra antes da janela só alimenta o LAG do primeiro bucket.
CREATE OR ALTER VIEW v_pbi_5min AS
WITH r AS (
  SELECT meter_id, DATEADD(minute, (DATEDIFF(minute, '2000-01-01', ts) / 5) * 5, '2000-01-01') AS bucket, kwh_import,
         ROW_NUMBER() OVER (PARTITION BY meter_id, DATEDIFF(minute, '2000-01-01', ts) / 5 ORDER BY ts DESC) AS rn
  FROM reading_slow
  WHERE ts > DATEADD(minute, -10, DATEADD(day, -7, SYSUTCDATETIME())) AND kwh_import IS NOT NULL),
e AS (
  SELECT meter_id, bucket, kwh_import AS kwh_acumulado,
         CASE WHEN kwh_import - LAG(kwh_import) OVER (PARTITION BY meter_id ORDER BY bucket) < 0 THEN kwh_import
              ELSE kwh_import - LAG(kwh_import) OVER (PARTITION BY meter_id ORDER BY bucket) END AS kwh
  FROM r WHERE rn = 1),
f AS (
  SELECT meter_id, DATEADD(minute, (DATEDIFF(minute, '2000-01-01', bucket) / 5) * 5, '2000-01-01') AS bucket,
         SUM(p_avg * samples) / NULLIF(SUM(CASE WHEN p_avg IS NULL THEN 0 ELSE samples END), 0) AS p_avg, MIN(p_min) AS p_min, MAX(p_max) AS p_max,
         SUM(q_avg * samples) / NULLIF(SUM(CASE WHEN q_avg IS NULL THEN 0 ELSE samples END), 0) AS q_avg, SUM(s_avg * samples) / NULLIF(SUM(CASE WHEN s_avg IS NULL THEN 0 ELSE samples END), 0) AS s_avg,
         SUM(i_avg * samples) / NULLIF(SUM(CASE WHEN i_avg IS NULL THEN 0 ELSE samples END), 0) AS i_avg, MAX(i_max) AS i_max,
         SUM(vln_avg * samples) / NULLIF(SUM(CASE WHEN vln_avg IS NULL THEN 0 ELSE samples END), 0) AS vln_avg, MIN(vln_min) AS vln_min, MAX(vln_max) AS vln_max, SUM(vll_avg * samples) / NULLIF(SUM(CASE WHEN vll_avg IS NULL THEN 0 ELSE samples END), 0) AS vll_avg,
         SUM(pf_avg * samples) / NULLIF(SUM(CASE WHEN pf_avg IS NULL THEN 0 ELSE samples END), 0) AS pf_avg, MIN(pf_min) AS pf_min, SUM(samples) AS samples
  FROM agg_1min WHERE bucket > DATEADD(day, -7, SYSUTCDATETIME())
  GROUP BY meter_id, DATEADD(minute, (DATEDIFF(minute, '2000-01-01', bucket) / 5) * 5, '2000-01-01'))
SELECT CAST(COALESCE(e.bucket, f.bucket) AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS bucket_local,
       COALESCE(e.bucket, f.bucket) AS bucket_utc, COALESCE(e.meter_id, f.meter_id) AS meter_id,
       f.p_avg, f.p_min, f.p_max, f.q_avg, f.s_avg, f.i_avg, f.i_max, f.vln_avg, f.vln_min, f.vln_max, f.vll_avg, f.pf_avg, f.pf_min, f.samples,
       e.kwh, e.kwh_acumulado,
       CAST(COALESCE(e.bucket, f.bucket) AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS dia_local
FROM e FULL OUTER JOIN f ON f.meter_id = e.meter_id AND f.bucket = e.bucket
JOIN meter m ON m.id = COALESCE(e.meter_id, f.meter_id) CROSS JOIN v_bic_tz z
WHERE COALESCE(e.bucket, f.bucket) > DATEADD(day, -7, SYSUTCDATETIME());
-- @@
CREATE OR ALTER VIEW v_pbi_15min AS
SELECT CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS bucket_local, a.bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, q_avg, s_avg, i_avg, i_max, vln_avg, vln_min, vln_max, pf_avg, pf_min, samples,
       CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS dia_local
FROM agg_15min a JOIN meter m ON m.id = a.meter_id CROSS JOIN v_bic_tz z
WHERE a.bucket > DATEADD(day, -90, SYSUTCDATETIME());
-- @@
-- Uma view por resolução com grandezas elétricas (agg_*) E energia (agg_energy_*) na mesma linha, para o Power BI
-- poder trocar a grandeza no mesmo eixo de tempo. Consumo por bucket = diferença do acumulador entre buckets
-- consecutivos (kwh_consumed do agregado só vê dentro do bucket); se o acumulador caiu (reset), vale o pós-reset.
CREATE OR ALTER VIEW v_pbi_1h AS
WITH e AS (
  SELECT meter_id, bucket, kwh_last AS kwh_acumulado,
         CASE WHEN kwh_last - LAG(kwh_last) OVER (PARTITION BY meter_id ORDER BY bucket) < 0 THEN kwh_last
              ELSE kwh_last - LAG(kwh_last) OVER (PARTITION BY meter_id ORDER BY bucket) END AS kwh,
         demand_peak, freq_avg, thd_ia, thd_ib, thd_ic, thd_van, thd_vbn, thd_vcn
  FROM agg_energy_1h)
SELECT CAST(COALESCE(a.bucket, e.bucket) AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS bucket_local,
       COALESCE(a.bucket, e.bucket) AS bucket_utc, COALESCE(a.meter_id, e.meter_id) AS meter_id,
       a.p_avg, a.p_min, a.p_max, a.q_avg, a.s_avg, a.i_avg, a.i_max, a.vln_avg, a.vln_min, a.vln_max, a.pf_avg, a.pf_min, a.samples,
       e.kwh, e.kwh_acumulado, e.demand_peak, e.freq_avg, e.thd_ia, e.thd_ib, e.thd_ic, e.thd_van, e.thd_vbn, e.thd_vcn,
       CAST(COALESCE(a.bucket, e.bucket) AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS dia_local
FROM agg_1h a FULL OUTER JOIN e ON e.meter_id = a.meter_id AND e.bucket = a.bucket
JOIN meter m ON m.id = COALESCE(a.meter_id, e.meter_id) CROSS JOIN v_bic_tz z;
-- @@
-- Buckets de 1 dia são dias UTC (como no agregado); dia_local é a data do bucket.
CREATE OR ALTER VIEW v_pbi_1d AS
WITH e AS (
  SELECT meter_id, bucket, kwh_last AS kwh_acumulado,
         CASE WHEN kwh_last - LAG(kwh_last) OVER (PARTITION BY meter_id ORDER BY bucket) < 0 THEN kwh_last
              ELSE kwh_last - LAG(kwh_last) OVER (PARTITION BY meter_id ORDER BY bucket) END AS kwh,
         demand_peak
  FROM agg_energy_1d)
SELECT COALESCE(a.bucket, e.bucket) AS bucket_local, COALESCE(a.bucket, e.bucket) AS bucket_utc, COALESCE(a.meter_id, e.meter_id) AS meter_id,
       a.p_avg, a.p_min, a.p_max, a.i_avg, a.i_max, a.vln_avg, a.vln_min, a.vln_max, a.pf_avg, a.pf_min, a.samples,
       e.kwh, e.kwh_acumulado, e.demand_peak,
       CAST(COALESCE(a.bucket, e.bucket) AS DATE) AS dia_local
FROM agg_1d a FULL OUTER JOIN e ON e.meter_id = a.meter_id AND e.bucket = a.bucket
JOIN meter m ON m.id = COALESCE(a.meter_id, e.meter_id);
-- @@
-- Consumo por bucket = diferença do acumulador entre buckets consecutivos (kwh_consumed do agregado só vê
-- dentro do bucket). Se o acumulador caiu (reset de energia), o consumo do bucket é o valor pós-reset.
CREATE OR ALTER VIEW v_pbi_energy_1h AS
SELECT CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS bucket_local, a.bucket AS bucket_utc, a.meter_id, kwh_last AS kwh_acumulado,
       CASE WHEN kwh_last - LAG(kwh_last) OVER (PARTITION BY a.meter_id ORDER BY a.bucket) < 0 THEN kwh_last
            ELSE kwh_last - LAG(kwh_last) OVER (PARTITION BY a.meter_id ORDER BY a.bucket) END AS kwh,
       demand_peak, freq_avg, thd_ia, thd_ib, thd_ic, thd_van, thd_vbn, thd_vcn,
       CAST(a.bucket AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS dia_local
FROM agg_energy_1h a JOIN meter m ON m.id = a.meter_id CROSS JOIN v_bic_tz z;
-- @@
CREATE OR ALTER VIEW v_pbi_energy_1d AS
SELECT a.bucket AS bucket_local, a.bucket AS bucket_utc, a.meter_id, kwh_last AS kwh_acumulado,
       CASE WHEN kwh_last - LAG(kwh_last) OVER (PARTITION BY a.meter_id ORDER BY a.bucket) < 0 THEN kwh_last
            ELSE kwh_last - LAG(kwh_last) OVER (PARTITION BY a.meter_id ORDER BY a.bucket) END AS kwh,
       demand_peak,
       CAST(a.bucket AS DATE) AS dia_local
FROM agg_energy_1d a JOIN meter m ON m.id = a.meter_id;
-- @@
CREATE OR ALTER VIEW v_pbi_agora AS
SELECT l.meter_id, l.machine, l.gateway, CAST(l.ts AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS leitura_local,
       p_total, q_total, s_total, pf_total, ia, ib, ic, i_avg, van, vbn, vcn, vln_avg, vll_avg,
       CAST(l.slow_ts AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATETIME2(0)) AS leitura_lenta_local,
       kwh_import, kwh_export, freq, demand_present, demand_peak
FROM v_meter_latest l CROSS JOIN v_bic_tz z;
-- @@
-- Dimensão de datas (um dia por linha, do primeiro dia com dados até amanhã) para o slicer de período.
CREATE OR ALTER VIEW v_pbi_calendario AS
WITH lim AS (
  SELECT CAST(COALESCE((SELECT MIN(bucket) FROM agg_1d), SYSUTCDATETIME()) AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE) AS d0,
         DATEADD(day, 1, CAST(SYSUTCDATETIME() AT TIME ZONE 'UTC' AT TIME ZONE z.tz AS DATE)) AS d1
  FROM v_bic_tz z),
n AS (SELECT TOP (36600) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS i FROM sys.all_objects a CROSS JOIN sys.all_objects b)
SELECT DATEADD(day, n.i, lim.d0) AS dia,
       ((DATEPART(weekday, DATEADD(day, n.i, lim.d0)) + @@DATEFIRST - 2) % 7) + 1 AS dia_semana,
       CONVERT(CHAR(7), DATEADD(day, n.i, lim.d0), 126) AS mes
FROM lim JOIN n ON n.i <= DATEDIFF(day, lim.d0, lim.d1);
