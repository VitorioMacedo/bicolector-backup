-- Cria o banco e o login da aplicação no SQL Server. Rodar UMA vez como administrador (sa ou sysadmin):
--   sqlcmd -S SERVIDOR -E -i sql\mssql_create_db.sql            (autenticação Windows)
--   sqlcmd -S SERVIDOR -U sa -P ... -C -i sql\mssql_create_db.sql
-- Troque a senha abaixo (e em DATABASE_URL do .env). O docker compose usa este mesmo arquivo no serviço db-init.
IF DB_ID('bic') IS NULL CREATE DATABASE bic;
GO
IF SUSER_ID('bic') IS NULL CREATE LOGIN bic WITH PASSWORD = 'BicDev2026x', CHECK_POLICY = OFF, DEFAULT_DATABASE = bic;
GO
USE bic;
GO
IF USER_ID('bic') IS NULL CREATE USER bic FOR LOGIN bic;
GO
-- A aplicação cria e altera tabelas, índices e views na inicialização: precisa ser dona do banco.
ALTER ROLE db_owner ADD MEMBER bic;
GO
