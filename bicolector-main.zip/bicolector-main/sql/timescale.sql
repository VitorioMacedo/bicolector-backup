-- Executado de forma idempotente na inicialização da aplicação (app/db/schema.py),
-- depois que as tabelas base foram criadas. Também pode ser aplicado manualmente com psql.
-- Cada comando é separado por uma linha com o marcador de dois arrobas (os agregados contínuos
-- não podem rodar dentro de uma transação, então cada comando é executado isoladamente).

CREATE EXTENSION IF NOT EXISTS timescaledb;
-- @@
-- Colunas acrescentadas depois da primeira versão (create_all não altera tabelas existentes).
ALTER TABLE gateway ADD COLUMN IF NOT EXISTS color VARCHAR(7);
-- @@
SELECT create_hypertable('reading_fast', 'ts', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
-- @@
SELECT create_hypertable('reading_slow', 'ts', chunk_time_interval => INTERVAL '7 days', if_not_exists => TRUE);
-- @@
SELECT create_hypertable('poll_cycle', 'ts', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
-- @@
CREATE INDEX IF NOT EXISTS ix_reading_fast_meter_ts ON reading_fast (meter_id, ts DESC);
-- @@
CREATE INDEX IF NOT EXISTS ix_reading_slow_meter_ts ON reading_slow (meter_id, ts DESC);
-- @@
ALTER TABLE reading_fast SET (timescaledb.compress, timescaledb.compress_segmentby = 'meter_id', timescaledb.compress_orderby = 'ts DESC');
-- @@
ALTER TABLE reading_slow SET (timescaledb.compress, timescaledb.compress_segmentby = 'meter_id', timescaledb.compress_orderby = 'ts DESC');
-- @@
SELECT add_compression_policy('reading_fast', INTERVAL '7 days', if_not_exists => TRUE);
-- @@
SELECT add_compression_policy('reading_slow', INTERVAL '30 days', if_not_exists => TRUE);
-- @@
-- Retenção da tabela bruta: padrão 90 dias; a aplicação reaplica quando a configuração raw_retention_days muda.
SELECT add_retention_policy('reading_fast', INTERVAL '90 days', if_not_exists => TRUE);
-- @@
SELECT add_retention_policy('poll_cycle', INTERVAL '30 days', if_not_exists => TRUE);
-- @@
-- ===== Agregados contínuos (o que o Power BI consulta) =====
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_1min WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 minute', ts) AS bucket, meter_id,
       avg(p_total) AS p_avg, min(p_total) AS p_min, max(p_total) AS p_max,
       avg(q_total) AS q_avg, avg(s_total) AS s_avg,
       avg(i_avg) AS i_avg, max(i_avg) AS i_max,
       avg(ia) AS ia_avg, avg(ib) AS ib_avg, avg(ic) AS ic_avg,
       avg(vln_avg) AS vln_avg, min(vln_avg) AS vln_min, max(vln_avg) AS vln_max,
       avg(vll_avg) AS vll_avg,
       avg(pf_total) AS pf_avg, min(pf_total) AS pf_min,
       count(*) AS samples
FROM reading_fast GROUP BY bucket, meter_id WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_1min', start_offset => INTERVAL '1 hour', end_offset => INTERVAL '1 minute', schedule_interval => INTERVAL '1 minute', if_not_exists => TRUE);
-- @@
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_15min WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '15 minutes', bucket) AS bucket, meter_id,
       avg(p_avg) AS p_avg, min(p_min) AS p_min, max(p_max) AS p_max,
       avg(q_avg) AS q_avg, avg(s_avg) AS s_avg,
       avg(i_avg) AS i_avg, max(i_max) AS i_max,
       avg(vln_avg) AS vln_avg, min(vln_min) AS vln_min, max(vln_max) AS vln_max,
       avg(pf_avg) AS pf_avg, min(pf_min) AS pf_min,
       sum(samples) AS samples
FROM agg_1min GROUP BY 1, 2 WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_15min', start_offset => INTERVAL '1 day', end_offset => INTERVAL '15 minutes', schedule_interval => INTERVAL '15 minutes', if_not_exists => TRUE);
-- @@
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_1h WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 hour', bucket) AS bucket, meter_id,
       avg(p_avg) AS p_avg, min(p_min) AS p_min, max(p_max) AS p_max,
       avg(q_avg) AS q_avg, avg(s_avg) AS s_avg,
       avg(i_avg) AS i_avg, max(i_max) AS i_max,
       avg(vln_avg) AS vln_avg, min(vln_min) AS vln_min, max(vln_max) AS vln_max,
       avg(pf_avg) AS pf_avg, min(pf_min) AS pf_min,
       sum(samples) AS samples
FROM agg_1min GROUP BY 1, 2 WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_1h', start_offset => INTERVAL '3 days', end_offset => INTERVAL '1 hour', schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);
-- @@
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_1d WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 day', bucket) AS bucket, meter_id,
       avg(p_avg) AS p_avg, min(p_min) AS p_min, max(p_max) AS p_max,
       avg(i_avg) AS i_avg, max(i_max) AS i_max,
       avg(vln_avg) AS vln_avg, min(vln_min) AS vln_min, max(vln_max) AS vln_max,
       avg(pf_avg) AS pf_avg, min(pf_min) AS pf_min,
       sum(samples) AS samples
FROM agg_1h GROUP BY 1, 2 WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_1d', start_offset => INTERVAL '30 days', end_offset => INTERVAL '1 day', schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);
-- @@
-- Energia: consumo no período = último kWh acumulado - primeiro (os acumuladores só crescem até um reset).
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_energy_1h WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 hour', ts) AS bucket, meter_id,
       first(kwh_import, ts) AS kwh_first, last(kwh_import, ts) AS kwh_last,
       last(kwh_import, ts) - first(kwh_import, ts) AS kwh_consumed,
       last(kwh_export, ts) - first(kwh_export, ts) AS kwh_exported,
       last(kvarh, ts) - first(kvarh, ts) AS kvarh_consumed,
       max(demand_peak) AS demand_peak, avg(freq) AS freq_avg,
       avg(thd_ia) AS thd_ia, avg(thd_ib) AS thd_ib, avg(thd_ic) AS thd_ic,
       avg(thd_van) AS thd_van, avg(thd_vbn) AS thd_vbn, avg(thd_vcn) AS thd_vcn
FROM reading_slow GROUP BY bucket, meter_id WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_energy_1h', start_offset => INTERVAL '3 days', end_offset => INTERVAL '1 hour', schedule_interval => INTERVAL '15 minutes', if_not_exists => TRUE);
-- @@
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_energy_1d WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 day', ts) AS bucket, meter_id,
       first(kwh_import, ts) AS kwh_first, last(kwh_import, ts) AS kwh_last,
       last(kwh_import, ts) - first(kwh_import, ts) AS kwh_consumed,
       last(kwh_export, ts) - first(kwh_export, ts) AS kwh_exported,
       max(demand_peak) AS demand_peak
FROM reading_slow GROUP BY bucket, meter_id WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_energy_1d', start_offset => INTERVAL '30 days', end_offset => INTERVAL '1 day', schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);
-- @@
-- ===== Agregados para o gráfico por grandeza (todas as colunas medidas) =====
-- agg_1min não pode ser alterado (é a base dos hierárquicos); estes cobrem todas as colunas e servem de base
-- para rollups na hora (15 min / 1 h / 1 dia) feitos pela aplicação.
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_fast_1min WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 minute', ts) AS bucket, meter_id,
       avg(ia) AS ia, avg(ib) AS ib, avg(ic) AS ic, avg(in_) AS in_, avg(i_avg) AS i_avg,
       avg(vab) AS vab, avg(vbc) AS vbc, avg(vca) AS vca, avg(vll_avg) AS vll_avg,
       avg(van) AS van, avg(vbn) AS vbn, avg(vcn) AS vcn, avg(vln_avg) AS vln_avg,
       avg(p_a) AS p_a, avg(p_b) AS p_b, avg(p_c) AS p_c, avg(p_total) AS p_total,
       avg(q_total) AS q_total, avg(s_total) AS s_total,
       avg(pf_total) AS pf_total, avg(pf_disp) AS pf_disp,
       count(*) AS samples
FROM reading_fast GROUP BY bucket, meter_id WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_fast_1min', start_offset => INTERVAL '3 days', end_offset => INTERVAL '1 minute', schedule_interval => INTERVAL '1 minute', if_not_exists => TRUE);
-- @@
ALTER MATERIALIZED VIEW agg_fast_1min SET (timescaledb.materialized_only = false);
-- @@
CREATE MATERIALIZED VIEW IF NOT EXISTS agg_slow_1h WITH (timescaledb.continuous) AS
SELECT time_bucket(INTERVAL '1 hour', ts) AS bucket, meter_id,
       avg(freq) AS freq, avg(demand_present) AS demand_present, avg(demand_last) AS demand_last,
       avg(demand_peak) AS demand_peak, max(demand_peak) AS demand_peak_max,
       avg(kwh_import) AS kwh_import, avg(kwh_export) AS kwh_export, avg(kwh_net) AS kwh_net,
       avg(kvarh) AS kvarh, avg(kvah) AS kvah,
       avg(thd_ia) AS thd_ia, avg(thd_ib) AS thd_ib, avg(thd_ic) AS thd_ic,
       avg(thd_van) AS thd_van, avg(thd_vbn) AS thd_vbn, avg(thd_vcn) AS thd_vcn,
       count(*) AS samples
FROM reading_slow GROUP BY bucket, meter_id WITH NO DATA;
-- @@
SELECT add_continuous_aggregate_policy('agg_slow_1h', start_offset => INTERVAL '30 days', end_offset => INTERVAL '1 hour', schedule_interval => INTERVAL '1 hour', if_not_exists => TRUE);
-- @@
ALTER MATERIALIZED VIEW agg_slow_1h SET (timescaledb.materialized_only = false);
-- @@
-- ===== Views simples para o Power BI =====
CREATE OR REPLACE VIEW v_meter AS
SELECT m.id AS meter_id, m.name AS machine, m.unit_id, m.enabled, g.id AS gateway_id, g.name AS gateway,
       g.color AS gateway_color
FROM meter m JOIN gateway g ON g.id = m.gateway_id;
-- @@
CREATE OR REPLACE VIEW v_meter_latest AS
SELECT v.meter_id, v.machine, v.gateway, f.ts, f.p_total, f.q_total, f.s_total, f.pf_total,
       f.ia, f.ib, f.ic, f.i_avg, f.van, f.vbn, f.vcn, f.vln_avg, f.vll_avg,
       s.ts AS slow_ts, s.kwh_import, s.kwh_export, s.freq, s.demand_present, s.demand_peak
FROM v_meter v
LEFT JOIN LATERAL (SELECT * FROM reading_fast r WHERE r.meter_id = v.meter_id AND r.ts > now() - INTERVAL '10 minutes' ORDER BY ts DESC LIMIT 1) f ON TRUE
LEFT JOIN LATERAL (SELECT * FROM reading_slow r WHERE r.meter_id = v.meter_id AND r.ts > now() - INTERVAL '1 hour' ORDER BY ts DESC LIMIT 1) s ON TRUE;
-- @@
-- Depois de um reset o acumulador resetável recomeça em zero, então o kWh atual É o consumo desde o reset.
CREATE OR REPLACE VIEW v_energy_since_reset AS
SELECT v.meter_id, v.machine,
       (SELECT max(ts) FROM command_log c WHERE c.meter_id = v.meter_id AND c.command = 'reset_energy' AND c.success) AS last_reset_at,
       s.kwh_import AS kwh_since_reset, s.ts AS as_of
FROM v_meter v
LEFT JOIN LATERAL (SELECT * FROM reading_slow r WHERE r.meter_id = v.meter_id ORDER BY ts DESC LIMIT 1) s ON TRUE;
-- @@
CREATE OR REPLACE VIEW v_poll_health AS
SELECT g.id AS gateway_id, g.name AS gateway, time_bucket(INTERVAL '1 minute', p.ts) AS bucket,
       avg(p.duration_ms) AS duration_avg_ms, max(p.duration_ms) AS duration_max_ms,
       max(p.interval_ms) AS interval_ms, sum(p.meters_failed) AS failures, count(*) AS cycles
FROM poll_cycle p JOIN gateway g ON g.id = p.gateway_id
GROUP BY 1, 2, 3;
-- @@
-- Desde o TimescaleDB 2.13 os agregados contínuos nascem com materialized_only = true, ou seja, sem a janela
-- ainda não materializada (último minuto/hora/dia). O painel de gráficos precisa dessa janela, então ligamos
-- a agregação em tempo real: o que ainda não foi materializado é calculado na hora a partir da hypertable.
ALTER MATERIALIZED VIEW agg_1min SET (timescaledb.materialized_only = false);
-- @@
ALTER MATERIALIZED VIEW agg_15min SET (timescaledb.materialized_only = false);
-- @@
ALTER MATERIALIZED VIEW agg_1h SET (timescaledb.materialized_only = false);
-- @@
ALTER MATERIALIZED VIEW agg_1d SET (timescaledb.materialized_only = false);
-- @@
ALTER MATERIALIZED VIEW agg_energy_1h SET (timescaledb.materialized_only = false);
-- @@
ALTER MATERIALIZED VIEW agg_energy_1d SET (timescaledb.materialized_only = false);
-- @@
-- ===== Views para o Power BI (gráficos do relatório powerbi/bic.pbip) =====
-- Horário local: os buckets são UTC; bic_local() converte para o fuso da configuração display_timezone.
CREATE OR REPLACE FUNCTION bic_local(ts timestamptz) RETURNS timestamp LANGUAGE sql STABLE AS $$
  SELECT ts AT TIME ZONE COALESCE((SELECT value FROM app_setting WHERE key = 'display_timezone'), 'America/Cuiaba')
$$;
-- @@
CREATE OR REPLACE VIEW v_pbi_1min AS
SELECT bic_local(bucket) AS bucket_local, bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, q_avg, s_avg, i_avg, i_max, ia_avg, ib_avg, ic_avg, vln_avg, vln_min, vln_max, vll_avg, pf_avg, pf_min, samples,
       bic_local(bucket)::date AS dia_local
FROM agg_1min a JOIN meter m ON m.id = a.meter_id WHERE bucket > now() - INTERVAL '7 days';
-- @@
CREATE OR REPLACE VIEW v_pbi_15min AS
SELECT bic_local(bucket) AS bucket_local, bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, q_avg, s_avg, i_avg, i_max, vln_avg, vln_min, vln_max, pf_avg, pf_min, samples,
       bic_local(bucket)::date AS dia_local
FROM agg_15min a JOIN meter m ON m.id = a.meter_id WHERE bucket > now() - INTERVAL '90 days';
-- @@
CREATE OR REPLACE VIEW v_pbi_1h AS
SELECT bic_local(bucket) AS bucket_local, bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, q_avg, s_avg, i_avg, i_max, vln_avg, vln_min, vln_max, pf_avg, pf_min, samples,
       bic_local(bucket)::date AS dia_local
FROM agg_1h a JOIN meter m ON m.id = a.meter_id;
-- @@
CREATE OR REPLACE VIEW v_pbi_1d AS
SELECT (bucket AT TIME ZONE 'UTC') AS bucket_local, bucket AS bucket_utc, a.meter_id,
       p_avg, p_min, p_max, i_avg, i_max, vln_avg, vln_min, vln_max, pf_avg, pf_min, samples,
       (bucket AT TIME ZONE 'UTC')::date AS dia_local
FROM agg_1d a JOIN meter m ON m.id = a.meter_id;
-- @@
-- Consumo por bucket = diferença do acumulador entre buckets consecutivos (kwh_consumed do agregado só vê
-- dentro do bucket). Se o acumulador caiu (reset de energia), o consumo do bucket é o valor pós-reset.
CREATE OR REPLACE VIEW v_pbi_energy_1h AS
SELECT bic_local(bucket) AS bucket_local, bucket AS bucket_utc, a.meter_id, kwh_last AS kwh_acumulado,
       CASE WHEN kwh_last - lag(kwh_last) OVER w < 0 THEN kwh_last ELSE kwh_last - lag(kwh_last) OVER w END AS kwh,
       demand_peak, freq_avg, thd_ia, thd_ib, thd_ic, thd_van, thd_vbn, thd_vcn,
       bic_local(bucket)::date AS dia_local
FROM agg_energy_1h a JOIN meter m ON m.id = a.meter_id WINDOW w AS (PARTITION BY a.meter_id ORDER BY bucket);
-- @@
CREATE OR REPLACE VIEW v_pbi_energy_1d AS
SELECT (bucket AT TIME ZONE 'UTC') AS bucket_local, bucket AS bucket_utc, a.meter_id, kwh_last AS kwh_acumulado,
       CASE WHEN kwh_last - lag(kwh_last) OVER w < 0 THEN kwh_last ELSE kwh_last - lag(kwh_last) OVER w END AS kwh,
       demand_peak,
       (bucket AT TIME ZONE 'UTC')::date AS dia_local
FROM agg_energy_1d a JOIN meter m ON m.id = a.meter_id WINDOW w AS (PARTITION BY a.meter_id ORDER BY bucket);
-- @@
CREATE OR REPLACE VIEW v_pbi_agora AS
SELECT meter_id, machine, gateway, bic_local(ts) AS leitura_local, p_total, q_total, s_total, pf_total,
       ia, ib, ic, i_avg, van, vbn, vcn, vln_avg, vll_avg, bic_local(slow_ts) AS leitura_lenta_local,
       kwh_import, kwh_export, freq, demand_present, demand_peak
FROM v_meter_latest;
-- @@
-- Dimensão de datas (um dia por linha) para o slicer de período filtrar todas as tabelas do Power BI.
CREATE OR REPLACE VIEW v_pbi_calendario AS
SELECT d::date AS dia, extract(isodow FROM d)::int AS dia_semana, to_char(d, 'YYYY-MM') AS mes
FROM generate_series(
       (SELECT COALESCE(min(bic_local(bucket))::date, bic_local(now())::date) FROM agg_1d),
       bic_local(now())::date + 1, INTERVAL '1 day') AS d;
