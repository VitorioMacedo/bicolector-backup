"""Login do painel (página /login, cookie de sessão), proteção das rotas e headers de segurança.

Sem override de require_auth: aqui o fluxo real de autenticação é exercitado. As credenciais vêm de variáveis de
ambiente (têm precedência sobre o .env), e o cache de settings é limpo a cada teste.
"""
from __future__ import annotations

import time

import httpx
import pytest
from argon2 import PasswordHasher
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.auth import session as session_mod
from app.auth.session import COOKIE_NAME, make_token, read_token
from app.auth.throttle import throttle
from app.config import get_settings
from app.db.models import Base
from app.db.session import get_session
from app.main import app

USER, PASSWORD, API_KEY = "operador", "senha-forte-123", "chave-teste"


@pytest.fixture
def env(monkeypatch):
    monkeypatch.setenv("ADMIN_USER", USER)
    monkeypatch.setenv("ADMIN_PASSWORD", PASSWORD)
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", "")
    monkeypatch.setenv("API_KEY", API_KEY)
    monkeypatch.setenv("SECRET_KEY", "segredo-de-teste")
    monkeypatch.setenv("LOGIN_MAX_ATTEMPTS", "3")
    monkeypatch.setenv("LOGIN_LOCKOUT_MINUTES", "15")
    get_settings.cache_clear()
    throttle.reset("127.0.0.1")
    throttle.reset("testclient")
    yield monkeypatch
    get_settings.cache_clear()
    app.dependency_overrides.clear()


@pytest.fixture
async def client(env):
    # ASGITransport não roda o lifespan: não toca no coletor; o banco é um SQLite em memória
    engine = create_async_engine("sqlite+aiosqlite://")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(engine, expire_on_commit=False)

    async def fake_session():
        async with Session() as s:
            yield s

    app.dependency_overrides[get_session] = fake_session
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        yield c
    await engine.dispose()


async def login(client: httpx.AsyncClient, password: str = PASSWORD, **extra) -> httpx.Response:
    return await client.post("/login", data={"username": USER, "password": password, **extra}, headers={"Origin": "http://t"})


# ---------- páginas e API sem sessão ----------

async def test_web_page_redirects_to_login(client):
    r = await client.get("/")
    assert r.status_code == 303
    assert r.headers["location"] == "/login?next=/"
    r = await client.get("/charts?range=24h")
    assert r.headers["location"] == "/login?next=/charts%3Frange%3D24h"


async def test_api_returns_401_without_basic_challenge(client):
    r = await client.get("/api/status")
    assert r.status_code == 401
    assert r.json() == {"detail": "não autenticado"}
    assert "www-authenticate" not in r.headers  # é isso que evita o popup do navegador


async def test_api_key_still_works(client):
    assert (await client.get("/api/commands", headers={"X-API-Key": "errada"})).status_code == 401
    r = await client.get("/api/commands", headers={"X-API-Key": API_KEY})
    assert r.status_code == 200 and r.json() == []
    assert (await client.get("/healthz")).status_code == 200  # continua aberto (monitoramento)


async def test_docs_require_login(client):
    for path in ("/docs", "/redoc", "/openapi.json"):
        r = await client.get(path)
        assert r.status_code == 303, path
        assert r.headers["location"].startswith("/login?next=")
    r = await login(client)
    r = await client.get("/docs")
    assert r.status_code == 200
    assert "swagger" in r.text.lower()
    r = await client.get("/openapi.json")
    assert r.status_code == 200 and "/api/status" in r.json()["paths"]


# ---------- login ----------

async def test_login_page_renders_with_branding(client):
    r = await client.get("/login?next=/charts")
    assert r.status_code == 200
    assert 'name="next" value="/charts"' in r.text
    assert "/static/logo.png" in r.text and "Entrar" in r.text
    assert r.headers["cache-control"] == "no-store"


async def test_login_wrong_password(client):
    r = await login(client, password="errada")
    assert r.status_code == 401
    assert "Usuário ou senha inválidos" in r.text
    assert "set-cookie" not in r.headers
    assert f'value="{USER}"' in r.text  # mantém o usuário digitado


async def test_login_success_sets_cookie_and_opens_everything(client):
    r = await login(client, next="/commands")
    assert r.status_code == 303
    assert r.headers["location"] == "/commands"
    cookie = r.headers["set-cookie"]
    assert cookie.startswith(f"{COOKIE_NAME}=")
    assert "HttpOnly" in cookie and "SameSite=lax" in cookie and "Path=/" in cookie and "Secure" not in cookie
    assert f"Max-Age={8 * 3600}" in cookie
    assert COOKIE_NAME in client.cookies

    r = await client.get("/login")
    assert r.status_code == 303 and r.headers["location"] == "/"  # já logado: não mostra o formulário
    r = await client.get("/api/commands")
    assert r.status_code == 200  # a sessão vale para a API JSON usada pelo painel
    r = await client.get("/commands")
    assert r.status_code == 200 and USER in r.text and 'action="/logout"' in r.text


async def test_login_remember_me_extends_session(client):
    r = await login(client, remember="1")
    assert f"Max-Age={30 * 86400}" in r.headers["set-cookie"]


async def test_login_rejects_open_redirect(client):
    for bad in ("//evil.com", "http://evil.com", "/\\evil.com", "javascript:alert(1)"):
        r = await login(client, next=bad)
        assert r.status_code == 303 and r.headers["location"] == "/", bad


async def test_login_with_password_hash(client, env):
    env.setenv("ADMIN_PASSWORD", "ignorada")
    env.setenv("ADMIN_PASSWORD_HASH", PasswordHasher().hash(PASSWORD))
    get_settings.cache_clear()
    assert (await login(client, password="ignorada")).status_code == 401
    assert (await login(client)).status_code == 303


async def test_lockout_after_failed_attempts(client):
    for _ in range(3):
        assert (await login(client, password="x")).status_code == 401
    r = await login(client)  # senha certa, mas o IP está bloqueado
    assert r.status_code == 429
    assert "Muitas tentativas" in r.text
    assert "set-cookie" not in r.headers


async def test_logout_clears_session(client):
    await login(client)
    r = await client.post("/logout", headers={"Origin": "http://t"})
    assert r.status_code == 303 and r.headers["location"] == "/login"
    assert "Max-Age=0" in r.headers["set-cookie"] or "expires" in r.headers["set-cookie"].lower()
    assert COOKIE_NAME not in client.cookies
    assert (await client.get("/")).status_code == 303


# ---------- CSRF (Origin) e headers de segurança ----------

async def test_cross_site_post_is_blocked(client):
    r = await client.post("/login", data={"username": USER, "password": PASSWORD}, headers={"Origin": "http://evil"})
    assert r.status_code == 403
    r = await client.post("/login", data={"username": USER, "password": PASSWORD}, headers={"Origin": "null"})
    assert r.status_code == 403
    r = await client.post("/login", data={"username": USER, "password": PASSWORD}, headers={"Referer": "http://evil/x"})
    assert r.status_code == 403
    await login(client)
    r = await client.post("/api/meters/1/reset-energy", headers={"Origin": "http://evil"})
    assert r.status_code == 403
    r = await client.post("/api/meters/1/reset-energy", headers={"Origin": "http://t"})
    assert r.status_code == 404  # mesma origem: passou pela autenticação e parou no "medidor não existe"
    # integrações (X-API-Key) não mandam Origin e não são afetadas; a chave errada continua 401
    client.cookies.clear()
    r = await client.post("/api/meters/1/reset-energy", headers={"X-API-Key": "qualquer", "Origin": "http://evil"})
    assert r.status_code == 401
    r = await client.post("/api/meters/1/reset-energy", headers={"X-API-Key": API_KEY})
    assert r.status_code == 404


async def test_security_headers(client):
    for path in ("/login", "/", "/healthz"):
        r = await client.get(path)
        assert r.headers["x-content-type-options"] == "nosniff", path
        assert r.headers["x-frame-options"] == "DENY", path
        assert "frame-ancestors 'none'" in r.headers["content-security-policy"], path
        assert "script-src 'self'" in r.headers["content-security-policy"], path
    assert "strict-transport-security" not in r.headers


async def test_hsts_and_secure_cookie_when_https(client, env):
    env.setenv("COOKIE_SECURE", "true")
    get_settings.cache_clear()
    r = await login(client)
    assert "Secure" in r.headers["set-cookie"]
    assert r.headers["strict-transport-security"].startswith("max-age=")


# ---------- token ----------

def test_token_roundtrip_and_tampering(env):
    token = make_token(USER, 3600)
    assert read_token(token) == USER
    assert read_token(None) is None
    assert read_token(token[:-3] + "xyz") is None
    head, _, sig = token.rpartition(".")
    assert read_token(head + ".AAAA") is None


def test_token_expires(env, monkeypatch):
    token = make_token(USER, 10)
    assert read_token(token) == USER
    real = time.time
    monkeypatch.setattr(time, "time", lambda: real() + 20)
    assert read_token(token) is None


def test_changing_password_invalidates_sessions(env):
    token = make_token(USER, 3600)
    env.setenv("ADMIN_PASSWORD", "outra-senha")
    get_settings.cache_clear()
    assert read_token(token) is None


def test_secret_key_generated_when_missing(env):
    env.setenv("SECRET_KEY", "")
    get_settings.cache_clear()
    session_mod._runtime_secret = None
    a = session_mod.secret_key()
    assert a and a == session_mod.secret_key()
    session_mod._runtime_secret = None
    assert session_mod.secret_key() != a
