"""Integração cliente ↔ simulador: leitura dos blocos, comandos de reset e latência do barramento."""
import asyncio
import socket
import time

import pytest

from app.modbus import registers as R
from app.modbus.client import GatewayClient, ModbusError
from app.modbus.commands import read_identification, send_command
from tests.sim_server import SimGateway


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
async def sim():
    port = free_port()
    gw = SimGateway(port, units=[1, 2, 3], latency_ms=20, host="127.0.0.1", offline={3})
    await gw.start()
    try:
        yield gw
    finally:
        await gw.stop()


@pytest.fixture
async def client(sim):
    c = GatewayClient(1, "sim", "127.0.0.1", sim.port, timeout=0.5, retries=0)
    assert await c.connect()
    try:
        yield c
    finally:
        c.close()


async def test_fast_block_decodes_plausible_values(client, sim):
    data = await client.read_block(1, R.FAST_FULL)
    assert 200 < data["vln_avg"] < 240
    assert data["p_total"] == pytest.approx(sim.meters[1].kw, rel=1e-5)
    assert 0.5 <= data["pf_total"] <= 1.0
    assert data["i_avg"] > 0


async def test_compact_block_and_slow_blocks(client, sim):
    compact = await client.read_block(1, R.FAST_COMPACT)
    assert set(compact) == {f.name for f in R.FAST_COMPACT.fields}
    slow = {}
    for b in R.SLOW_BLOCKS:
        slow.update(await client.read_block(1, b))
    assert slow["kwh_import"] == pytest.approx(sim.meters[1].kwh_import, rel=1e-5)
    assert 59 < slow["freq"] < 61
    assert slow["thd_ia"] >= 0


async def test_offline_unit_raises_modbus_error(client):
    with pytest.raises(ModbusError):
        await client.read_registers(3, R.FAST_FULL.address0, R.FAST_FULL.count)


async def test_late_gateway_response_never_hangs_nor_misattributes():
    """Gateway demora mais que o timeout do cliente para o medidor ausente, então a resposta chega atrasada
    e o barramento fica ocupado. Exigências: nenhuma chamada trava além do hard_timeout, nenhuma leitura é
    atribuída ao medidor errado, e quando o barramento libera o cliente volta a ler normalmente."""
    port = free_port()
    gw = SimGateway(port, units=[1, 3], latency_ms=5, host="127.0.0.1", offline={3}, gateway_timeout_s=0.6)
    await gw.start()
    c = GatewayClient(1, "sim", "127.0.0.1", port, timeout=0.2, retries=0)
    try:
        assert await c.connect()
        for _ in range(3):
            t0 = time.perf_counter()
            with pytest.raises(ModbusError):
                await c.read_registers(3, R.FAST_FULL.address0, R.FAST_FULL.count)  # medidor ausente
            assert time.perf_counter() - t0 < c.hard_timeout + 0.5
            # tempestade de respostas atrasadas: pode falhar, mas nunca travar nem devolver dado de outro unit
            for _ in range(3):
                t0 = time.perf_counter()
                try:
                    data = await c.read_block(1, R.FAST_FULL)
                    assert data["p_total"] == pytest.approx(gw.meters[1].kw, rel=1e-5)
                except ModbusError:
                    pass
                assert time.perf_counter() - t0 < c.hard_timeout + 0.5
            await asyncio.sleep(0.8)  # barramento libera
            data = await asyncio.wait_for(c.read_block(1, R.FAST_FULL), 3.0)
            assert data["p_total"] == pytest.approx(gw.meters[1].kw, rel=1e-5)
    finally:
        c.close()
        await gw.stop()


async def test_reset_energy_zeroes_accumulators(client, sim):
    assert sim.meters[2].kwh_import > 100
    async with client.lock:
        res = await send_command(client, 2, 2020, password=0, layout="password_first")
    assert res.success, res.detail
    assert sim.meters[2].kwh_import < 1.0
    slow = await client.read_block(2, R.SLOW_ENERGY)
    assert slow["kwh_import"] < 1.0


async def test_unknown_command_falls_back_and_fails(client, sim):
    async with client.lock:
        res = await send_command(client, 1, 9999)
    assert not res.success
    assert res.result_code == 3001


async def test_identification(client):
    async with client.lock:
        ident = await read_identification(client, 1)
    assert ident["serial_number"] == "2024000001"
    assert ident["firmware"] == "1.5.3"
    assert ident["ct_primary"] == 400


async def test_offline_unit_never_receives_another_units_data():
    """Timeout do cliente igual ao do gateway (caso limite real): o medidor ausente jamais pode receber
    dados de outro medidor por causa de uma resposta atrasada."""
    port = free_port()
    gw = SimGateway(port, units=[1, 2], latency_ms=5, host="127.0.0.1", offline={2}, gateway_timeout_s=0.3)
    await gw.start()
    c = GatewayClient(1, "sim", "127.0.0.1", port, timeout=0.3, retries=0)
    try:
        assert await c.connect()
        ok_1 = 0
        for _ in range(8):
            for unit in (1, 2):
                try:
                    data = await c.read_block(unit, R.FAST_FULL)
                except ModbusError:
                    continue
                assert unit == 1, "medidor ausente devolveu dados"
                assert data["p_total"] == pytest.approx(gw.meters[1].kw, rel=1e-5)
                ok_1 += 1
        assert ok_1 >= 4
    finally:
        c.close()
        await gw.stop()


async def test_bus_serializes_requests(sim):
    """Duas conexões ao mesmo gateway não aceleram: o barramento é half-duplex (latência somada)."""
    c1 = GatewayClient(1, "a", "127.0.0.1", sim.port, timeout=1.0, retries=0)
    c2 = GatewayClient(1, "b", "127.0.0.1", sim.port, timeout=1.0, retries=0)
    assert await c1.connect() and await c2.connect()
    try:
        t0 = time.perf_counter()
        await asyncio.gather(*[c1.read_block(1, R.FAST_FULL) for _ in range(5)], *[c2.read_block(2, R.FAST_FULL) for _ in range(5)])
        elapsed = time.perf_counter() - t0
        assert elapsed >= 10 * 0.02 * 0.9
    finally:
        c1.close()
        c2.close()
