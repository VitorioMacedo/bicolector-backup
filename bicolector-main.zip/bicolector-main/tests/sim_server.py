"""Simulador de um gateway Link150 com N medidores PM2230 atrás dele (Modbus TCP).

Reproduz o que importa para o coletor:
  - mapa de registradores do PM2230 (blocos rápido/lento/identificação) com valores que variam a cada segundo;
  - latência configurável por requisição e serialização (barramento RS-485 é half-duplex);
  - interface de comandos (5249/5250 sem semáforo, 5000+5680 protegida) com reset de energia real.

    uv run python -m tests.sim_server --port 5020 --units 1-10 --latency-ms 80
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import math
import random
import time

from pymodbus.constants import ExcCodes
from pymodbus.datastore import ModbusServerContext
from pymodbus.server import ModbusTcpServer

from app.modbus import registers as R

log = logging.getLogger("sim")

ACCEPTED_RESET_CODES = {2020, 1003}  # ambos os códigos citados nas fontes; o medidor real aceita só um
SEMAPHORE = 62283
MAP_END = 7000  # último endereço 0-based respondido pelo simulador


def _f32(regs: dict[int, int], reg1: int, value: float) -> None:
    hi, lo = R.encode_f32(value)
    regs[reg1 - 1], regs[reg1] = hi, lo


class SimMeter:
    """Modelo elétrico simples de uma máquina trifásica medida por um PM2230."""

    def __init__(self, unit: int, seed: int | None = None):
        self.unit = unit
        self.rnd = random.Random(seed if seed is not None else unit)
        self.base_kw = self.rnd.uniform(5, 60)
        self.kw = self.base_kw
        self.pf = self.rnd.uniform(0.82, 0.96)
        self.kwh_import = self.rnd.uniform(1000, 50000)
        self.kwh_export = 0.0
        self.kvarh = self.kwh_import * 0.4
        self.kvah = self.kwh_import * 1.1
        self.demand_peak = self.base_kw * 1.3
        self.regs: dict[int, int] = {}
        self.last_tick = time.monotonic()
        self.tick()

    def tick(self) -> None:
        now = time.monotonic()
        dt = max(0.0, now - self.last_tick)
        self.last_tick = now
        # passeio aleatório em torno da base; de vez em quando a máquina "desliga"
        self.kw = max(0.0, self.kw + self.rnd.gauss(0, 0.8) + 0.05 * (self.base_kw - self.kw))
        if self.rnd.random() < 0.002:
            self.kw = 0.3
        pf = min(0.99, max(0.5, self.pf + self.rnd.gauss(0, 0.005)))
        vln = 220 + self.rnd.gauss(0, 1.5)
        vll = vln * math.sqrt(3)
        s_kva = self.kw / pf if pf else 0
        q_kvar = math.sqrt(max(0.0, s_kva**2 - self.kw**2))
        i_avg = (s_kva * 1000) / (3 * vln) if vln else 0
        self.kwh_import += self.kw * dt / 3600
        self.kvarh += q_kvar * dt / 3600
        self.kvah += s_kva * dt / 3600
        self.demand_peak = max(self.demand_peak, self.kw)

        r = self.regs
        ia, ib, ic = (i_avg * (1 + self.rnd.gauss(0, 0.02)) for _ in range(3))
        _f32(r, 3000, ia); _f32(r, 3002, ib); _f32(r, 3004, ic); _f32(r, 3006, abs(ia - ib) * 0.1); _f32(r, 3010, (ia + ib + ic) / 3)
        _f32(r, 3020, vll); _f32(r, 3022, vll + 0.5); _f32(r, 3024, vll - 0.5); _f32(r, 3026, vll)
        _f32(r, 3028, vln); _f32(r, 3030, vln + 0.3); _f32(r, 3032, vln - 0.3); _f32(r, 3036, vln)
        _f32(r, 3054, self.kw / 3); _f32(r, 3056, self.kw / 3); _f32(r, 3058, self.kw / 3); _f32(r, 3060, self.kw)
        _f32(r, 3068, q_kvar); _f32(r, 3076, s_kva)
        _f32(r, 3084, pf); _f32(r, 3092, pf + 0.01)
        _f32(r, 3110, 60 + self.rnd.gauss(0, 0.02))
        _f32(r, 3142, self.kw * 0.98); _f32(r, 3148, self.kw * 0.95); _f32(r, 3154, self.demand_peak)
        _f32(r, 3204, self.kwh_import); _f32(r, 3206, self.kwh_export); _f32(r, 3208, self.kvarh)
        _f32(r, 3214, self.kvah); _f32(r, 3222, self.kwh_import - self.kwh_export)
        for reg in (2130, 2132, 2134):
            _f32(r, reg, abs(self.rnd.gauss(8, 1.5)))
        for reg in (2138, 2140, 2142):
            _f32(r, reg, abs(self.rnd.gauss(2, 0.4)))
        serial = 2024000000 + self.unit
        r[129], r[130] = serial >> 16, serial & 0xFFFF
        r[1636], r[1637], r[1638] = 0x0105, 0x0003, 2
        r[2003], r[2004] = 400, 5
        r.setdefault(R.CMD_UNPROTECTED_RESULT - 1, 0)
        r.setdefault(R.CMD_PROTECTED_RESULT - 1, 0)
        r[R.CMD_SEMAPHORE - 1] = SEMAPHORE

    def reset_energy(self) -> None:
        self.kwh_import = self.kwh_export = self.kvarh = self.kvah = 0.0
        self.tick()

    # -- comandos ---------------------------------------------------------
    def handle_command(self, address0: int, values: list[int]) -> bool:
        """Interpreta escritas na interface de comandos. Retorna False se o endereço não é de comando."""
        if address0 == R.CMD_UNPROTECTED_PASSWORD - 1 and len(values) >= 2:      # [senha, comando, ...]
            code = values[1]
            result_reg = R.CMD_UNPROTECTED_RESULT - 1
        elif address0 == R.CMD_UNPROTECTED_COMMAND - 1 and values:               # [comando, 0, ...]
            code = values[0]
            result_reg = R.CMD_UNPROTECTED_RESULT - 1
        elif address0 == R.CMD_PROTECTED_COMMAND - 1 and len(values) >= 2:      # [comando, semáforo, ...]
            code = values[0]
            result_reg = R.CMD_PROTECTED_RESULT - 1
            if values[1] != SEMAPHORE:
                self.regs[result_reg] = 3000
                return True
        else:
            return False
        if code in ACCEPTED_RESET_CODES:
            self.reset_energy()
            self.regs[result_reg] = 0
            log.info("unit %s: energia zerada (comando %s)", self.unit, code)
        elif code in (1001, 1002):
            self.regs[result_reg] = 0
        else:
            self.regs[result_reg] = 3001  # comando inválido
        return True


class SimContext(ModbusServerContext):
    """Contexto do servidor pymodbus com latência e serialização por "barramento".

    Tempo de cada requisição = turnaround fixo do medidor (latency_s) + tempo de transmissão serial
    dos bytes RTU na velocidade configurada (11 bits por byte): assim um bloco menor é mais rápido,
    como no barramento real.
    """

    def __init__(self, meters: dict[int, SimMeter], latency_s: float, offline: set[int] | None = None, baud: int = 38400, gateway_timeout_s: float = 1.0):
        # não chama super().__init__: o servidor usa o contexto diretamente quando old_simulator=True
        self.simdevices = []
        self.old_simulator = True
        self.meters = meters
        self.latency_s = latency_s
        self.baud = baud
        self.gateway_timeout_s = gateway_timeout_s
        self.offline = offline or set()
        self.bus = asyncio.Lock()
        self.requests = 0

    def device_ids(self) -> list[int]:
        return list(self.meters)

    def serial_time(self, request_bytes: int, response_bytes: int) -> float:
        return (request_bytes + response_bytes) * 11 / self.baud + 2 * 3.5 * 11 / self.baud

    async def _bus_delay(self, request_bytes: int, response_bytes: int) -> None:
        async with self.bus:  # half-duplex: uma requisição por vez no barramento
            await asyncio.sleep(self.latency_s + self.serial_time(request_bytes, response_bytes))

    async def async_getValues(self, device_id: int, func_code: int, address: int, count: int = 1):
        self.requests += 1
        meter = self.meters.get(device_id)
        if meter is None or device_id in self.offline:
            async with self.bus:
                await asyncio.sleep(self.gateway_timeout_s)  # medidor ausente: o gateway espera seu timeout serial
            return ExcCodes.GATEWAY_NO_RESPONSE
        if func_code not in (3, 4):
            return ExcCodes.ILLEGAL_FUNCTION
        await self._bus_delay(8, 5 + 2 * count)
        regs = meter.regs
        if address + count > MAP_END:
            return ExcCodes.ILLEGAL_ADDRESS
        # buracos do mapa (registradores reservados) respondem 0, como no medidor real
        return [regs.get(a, 0) for a in range(address, address + count)]

    async def async_setValues(self, device_id: int, func_code: int, address: int, values):
        self.requests += 1
        meter = self.meters.get(device_id)
        if meter is None or device_id in self.offline:
            return ExcCodes.GATEWAY_NO_RESPONSE
        if func_code not in (6, 16):
            return ExcCodes.ILLEGAL_FUNCTION
        await self._bus_delay(9 + 2 * len(values), 8)
        if meter.handle_command(address, list(values)):
            return None
        for i, v in enumerate(values):
            meter.regs[address + i] = int(v) & 0xFFFF
        return None


async def tick_loop(meters: dict[int, SimMeter], stop: asyncio.Event) -> None:
    while not stop.is_set():
        for m in meters.values():
            m.tick()
        try:
            await asyncio.wait_for(stop.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            pass


def parse_units(spec: str) -> list[int]:
    out: list[int] = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


class SimGateway:
    """Gateway simulado: servidor TCP + medidores + loop de atualização. Usado pelo CLI e pelos testes."""

    def __init__(self, port: int, units: list[int], latency_ms: float = 25, host: str = "0.0.0.0", offline: set[int] | None = None, baud: int = 38400, gateway_timeout_s: float = 1.0):
        self.meters = {u: SimMeter(u, seed=port * 1000 + u) for u in units}
        self.context = SimContext(self.meters, latency_ms / 1000, offline, baud=baud, gateway_timeout_s=gateway_timeout_s)
        self.server = ModbusTcpServer(self.context, address=(host, port))
        self.port = port
        self._stop = asyncio.Event()
        self._tasks: list[asyncio.Task] = []

    async def start(self) -> None:
        self._tasks = [asyncio.create_task(tick_loop(self.meters, self._stop)), asyncio.create_task(self.server.serve_forever())]
        await asyncio.sleep(0.2)

    async def stop(self) -> None:
        self._stop.set()
        await self.server.shutdown()
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)


async def main_async(args: argparse.Namespace) -> None:
    units = parse_units(args.units)
    gw = SimGateway(args.port, units, args.latency_ms, host=args.host, offline=set(parse_units(args.offline)) if args.offline else None,
                    baud=args.baud, gateway_timeout_s=args.gateway_timeout)
    full_ms = (args.latency_ms / 1000 + gw.context.serial_time(8, 5 + 2 * R.FAST_FULL.count)) * 1000
    log.info("simulador na porta %s: units %s, turnaround %s ms + serial a %s bps (bloco full ≈ %.0f ms)", args.port, units, args.latency_ms, args.baud, full_ms)
    await gw.start()
    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        await gw.stop()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5020)
    ap.add_argument("--units", default="1-10")
    ap.add_argument("--latency-ms", type=float, default=25, help="turnaround do medidor por requisição (sem o tempo serial)")
    ap.add_argument("--baud", type=int, default=38400, help="velocidade do barramento RS-485 simulado")
    ap.add_argument("--gateway-timeout", type=float, default=1.0, help="timeout serial do gateway para medidor ausente (s)")
    ap.add_argument("--offline", default="", help="units que não respondem (ex.: 3,7)")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("pymodbus").setLevel(logging.ERROR)
    try:
        asyncio.run(main_async(args))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
