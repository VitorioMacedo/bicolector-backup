import math

import pytest

from app.modbus import registers as R


def test_decode_f32_big_endian_word_order():
    hi, lo = R.encode_f32(230.5)
    assert R.decode_f32(hi, lo) == pytest.approx(230.5)
    # 0x4348 0x0000 = 200.0
    assert R.decode_f32(0x4348, 0x0000) == pytest.approx(200.0)


def test_decode_f32_nan_becomes_none():
    assert R.decode_f32(0xFFC0, 0x0000) is None
    assert R.decode_f32(0x7F80, 0x0000) is None  # +inf


@pytest.mark.parametrize("block", [R.FAST_FULL, R.FAST_COMPACT, *R.SLOW_BLOCKS, R.IDENT_SERIAL, R.IDENT_FIRMWARE, R.IDENT_CT])
def test_blocks_fit_in_one_fc03_and_fields_inside(block: R.Block):
    assert 1 <= block.count <= 125
    for f in block.fields:
        size = 2 if f.kind in ("f32", "u32", "raw2") else 1
        assert block.start <= f.reg, f
        assert f.reg + size <= block.start + block.count, f


def test_fast_full_covers_required_quantities():
    names = {f.name for f in R.FAST_FULL.fields}
    assert {"ia", "ib", "ic", "i_avg", "van", "vbn", "vcn", "vln_avg", "p_total", "pf_total"} <= names
    assert R.FAST_FULL.start == 3000 and R.FAST_FULL.count == 94


def test_fast_compact_is_subset_with_averages():
    names = {f.name for f in R.FAST_COMPACT.fields}
    assert {"i_avg", "vln_avg", "vll_avg", "p_total", "pf_total", "q_total", "s_total"} <= names
    assert "ia" not in names and "pf_disp" not in names
    assert R.FAST_COMPACT.count == 76


def test_block_decode_maps_offsets():
    regs = [0] * R.FAST_FULL.count
    hi, lo = R.encode_f32(12.5)
    off = 3060 - 3000  # p_total
    regs[off], regs[off + 1] = hi, lo
    hi, lo = R.encode_f32(0.95)
    off = 3084 - 3000  # pf_total
    regs[off], regs[off + 1] = hi, lo
    out = R.FAST_FULL.decode(regs)
    assert out["p_total"] == pytest.approx(12.5)
    assert out["pf_total"] == pytest.approx(0.95)
    assert out["ia"] == 0.0


def test_block_decode_rejects_short_response():
    with pytest.raises(ValueError):
        R.FAST_FULL.decode([0] * 10)


def test_format_firmware():
    assert R.format_firmware((0x0105 << 16) | 0x0003) == "1.5.3"


def test_encode_roundtrip_random_values():
    for v in (0.0, -1.0, 1e-3, 123456.78, 3.4e38):
        hi, lo = R.encode_f32(v)
        d = R.decode_f32(hi, lo)
        assert d is not None and math.isclose(d, v, rel_tol=1e-6)
