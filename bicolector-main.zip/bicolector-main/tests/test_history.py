"""Endpoints dos gráficos: catálogo de grandezas, seleção de bucket, alinhamento das séries, ranking de kWh.

As rotas são testadas com uma sessão falsa (linhas enlatadas), sem banco. O SQL real (T-SQL: buckets por
DATEDIFF_BIG, ROW_NUMBER, LAG, tabelas de resumo + cauda bruta) só roda em test_history_sql_mssql, que precisa de
BIC_TEST_DATABASE_URL apontando para um SQL Server (o teste aplica o esquema).
"""
from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta

import httpx
import pytest
from fastapi import HTTPException

from app import services
from app.api.deps import require_auth
from app.db.models import FAST_COLUMNS, SLOW_COLUMNS
from app.db.session import get_session
from app.main import app


# ----------------------------------------------------------------------------- funções puras
def test_metrics_cover_all_columns():
    missing = [c for c in FAST_COLUMNS + SLOW_COLUMNS if c not in services.METRICS]
    assert missing == []
    assert services.METRICS["kwh"].source == "energy"
    assert all(services.METRICS[c].source == "fast" for c in FAST_COLUMNS)
    assert all(services.METRICS[c].source == "slow" for c in SLOW_COLUMNS)
    cat = services.metric_catalog()
    assert {c["key"] for c in cat} == set(services.METRICS) and cat[0]["group"] == "Energia"
    by_key = {c["key"]: c for c in cat}
    assert by_key["kwh"]["min_step_s"] == 300 and by_key["thd_ia"]["min_step_s"] == 60 and by_key["ia"]["min_step_s"] == 1
    with pytest.raises(HTTPException) as exc:
        services.get_metric("xpto")
    assert exc.value.status_code == 422


@pytest.mark.parametrize(
    "span, label, source, energy_source",
    [
        (timedelta(minutes=15), "1s", "reading_fast", "reading_slow"),
        (timedelta(minutes=16), "5s", "reading_fast", "reading_slow"),
        (timedelta(hours=1), "5s", "reading_fast", "reading_slow"),
        (timedelta(hours=6), "30s", "reading_fast", "reading_slow"),
        (timedelta(hours=24), "1min", "agg_fast_1min", "reading_slow"),
        (timedelta(days=7), "15min", "agg_fast_1min", "agg_energy_1h"),
        (timedelta(days=30), "1h", "agg_fast_1min", "agg_energy_1d"),
        (timedelta(days=91), "1d", "agg_fast_1min", "agg_energy_1d"),
    ],
)
def test_choose_bucket_boundaries(span, label, source, energy_source):
    plan = services.choose_bucket(span)
    assert (plan.label, plan.source, plan.energy_source) == (label, source, energy_source)
    assert span.total_seconds() / plan.step_s <= 1500


@pytest.mark.parametrize(
    "metric, span, bucket, label, source",
    [
        ("ia", timedelta(hours=1), "auto", "5s", "reading_fast"),
        ("ia", timedelta(hours=24), "auto", "1min", "agg_fast_1min"),
        ("ia", timedelta(days=30), "1min", "1min", "agg_fast_1min"),      # 43 200 pontos: dentro do limite
        ("ia", timedelta(days=30), "1d", "1d", "agg_fast_1min"),
        ("ia", timedelta(days=7), "30s", "30s", "reading_fast"),            # forçado na hypertable
        ("thd_ia", timedelta(minutes=15), "auto", "1min", "reading_slow"),  # lento: mínimo 1 min
        ("thd_ia", timedelta(hours=6), "1s", "1min", "reading_slow"),
        ("thd_ia", timedelta(days=7), "auto", "15min", "reading_slow"),
        ("demand_peak", timedelta(days=30), "auto", "1h", "agg_slow_1h"),
        ("freq", timedelta(days=100), "auto", "1d", "agg_slow_1h"),
        ("kwh", timedelta(hours=1), "auto", "5min", "reading_slow"),
        ("kwh", timedelta(hours=6), "1s", "5min", "reading_slow"),          # energia: mínimo 5 min
        ("kwh", timedelta(days=7), "auto", "1h", "agg_energy_1h"),
        ("kwh", timedelta(days=7), "1d", "1d", "agg_energy_1d"),
        ("kwh", timedelta(days=30), "15min", "15min", "reading_slow"),
    ],
)
def test_plan_for_metric(metric, span, bucket, label, source):
    plan = services.plan_for_metric(services.METRICS[metric], span, bucket)
    assert (plan.label, plan.source) == (label, source)
    assert plan.step_s == services.BUCKET_SECONDS[label]


def test_plan_for_metric_rejects_too_many_points_and_bad_bucket():
    with pytest.raises(HTTPException) as exc:
        services.plan_for_metric(services.METRICS["ia"], timedelta(days=30), "1s")
    assert exc.value.status_code == 422 and "resolução" in exc.value.detail
    with pytest.raises(HTTPException):
        services.plan_for_metric(services.METRICS["ia"], timedelta(days=1), "2h")


def test_metric_sql_uses_catalog_column_and_aggregator():
    sql = str(services._metric_sql(services.METRICS["in_"], "reading_fast"))
    assert "in_ AS v FROM reading_fast" in sql and "avg(v) AS v" in sql and "DATEDIFF_BIG(second, '1970-01-01', ts) / :step" in sql
    sql = str(services._metric_sql(services.METRICS["demand_peak"], "agg_slow_1h"))
    assert "demand_peak_max AS v FROM agg_slow_1h" in sql and "max(v) AS v" in sql
    # cauda bruta a partir do watermark do agregado, reduzida ao bucket base (1 h) com o mesmo agregador
    assert "watermark FROM agg_state WHERE name = 'agg_slow_1h'" in sql and "/ 3600) * 3600" in sql and "max(demand_peak)" not in sql
    assert "SELECT meter_id, b, max(v) AS v FROM" in sql and "demand_peak AS v FROM reading_slow" in sql
    sql = str(services._metric_sql(services.METRICS["vab"], "agg_fast_1min"))
    assert "vab AS v FROM agg_fast_1min" in sql and "(b / :step) * :step AS bucket" in sql and "/ 60) * 60" in sql
    sql = str(services._metric_sql(services.METRICS["kwh"], "agg_energy_1h"))
    assert "lag(kwh_last)" in sql and "FROM agg_energy_1h" in sql and "ROW_NUMBER() OVER (PARTITION BY meter_id" in sql
    for src, stmt in services._RANKING_SQL.items():
        assert "sum(v) AS kwh" in str(stmt) and src in str(stmt)


def test_parse_meter_ids():
    assert services.parse_meter_ids("3, 4,3,,7") == [3, 4, 7]
    with pytest.raises(HTTPException):
        services.parse_meter_ids(",".join(str(i) for i in range(1, services.MAX_HISTORY_METERS + 2)))
    with pytest.raises(HTTPException):
        services.parse_meter_ids("a")
    with pytest.raises(HTTPException):
        services.parse_meter_ids("")


def test_parse_history_window():
    now = datetime(2026, 10, 22, 12, 0, tzinfo=UTC)
    frm, to = services.parse_history_window("6h", None, None, now=now)
    assert to == now and frm == now - timedelta(hours=6)
    frm, to = services.parse_history_window(None, "2026-10-21T00:00:00Z", "2026-10-22T00:00:00Z", now=now)
    assert frm.tzinfo is not None and (to - frm) == timedelta(days=1)
    frm, to = services.parse_history_window(None, "2026-10-21T00:00:00", None, now=now)  # naive -> UTC, to = agora
    assert frm.tzinfo is UTC and to == now
    for args in [("1y", None, None), (None, None, None), (None, "2026-10-22T00:00:00Z", "2026-10-21T00:00:00Z"), (None, "2020-01-01T00:00:00Z", None)]:
        with pytest.raises(HTTPException):
            services.parse_history_window(*args, now=now)


def test_align_fills_nulls():
    t0 = datetime(2026, 10, 22, 12, 0, tzinfo=UTC)
    rows = [
        {"meter_id": 1, "bucket": t0, "v": 1.0},
        {"meter_id": 1, "bucket": t0 + timedelta(seconds=30), "v": 2.0},
        {"meter_id": 2, "bucket": t0 + timedelta(seconds=30), "v": 5.0},
        {"meter_id": 2, "bucket": t0 + timedelta(seconds=60), "v": None},
        {"meter_id": 9, "bucket": t0, "v": 99.0},  # medidor não pedido: ignorado
    ]
    t, series = services._align(rows, [1, 2])
    assert t == [int(t0.timestamp()), int(t0.timestamp()) + 30, int(t0.timestamp()) + 60]
    assert series[1] == [1.0, 2.0, None]
    assert series[2] == [None, 5.0, None]
    # frm descarta o bucket que só alimenta o lag da energia
    t, series = services._align(rows, [1], frm=t0 + timedelta(seconds=30))
    assert t == [int(t0.timestamp()) + 30, int(t0.timestamp()) + 60] and series[1] == [2.0, None]


# ----------------------------------------------------------------------------- rotas com sessão falsa
class _Result:
    def __init__(self, rows):
        self._rows = rows

    def mappings(self):
        return self

    def all(self):
        return self._rows


class FakeSession:
    """Devolve linhas enlatadas conforme o SQL: ranking (sum), energia (lag) ou série simples."""

    def __init__(self, rows, energy_rows, ranking_rows):
        self.rows, self.energy_rows, self.ranking_rows = rows, energy_rows, ranking_rows
        self.calls: list[tuple[str, dict]] = []

    async def execute(self, stmt, params=None):
        sql = str(stmt)
        self.calls.append((sql, params or {}))
        if "sum(v) AS kwh" in sql:
            return _Result(self.ranking_rows)
        if "lag(kwh_last)" in sql:
            return _Result(self.energy_rows)
        return _Result(self.rows)


class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


@pytest.fixture
def client(monkeypatch):
    t0 = datetime.now(UTC).replace(microsecond=0) - timedelta(minutes=5)
    rows = [
        {"meter_id": 1, "bucket": t0, "v": 10.0},
        {"meter_id": 2, "bucket": t0 + timedelta(seconds=5), "v": 11.0},
    ]
    energy = [
        {"meter_id": 1, "bucket": t0 - timedelta(hours=2), "kwh_last": 100.0, "v": None},  # seed do lag (antes de frm)
        {"meter_id": 1, "bucket": t0, "kwh_last": 101.5, "v": 1.5},
    ]
    ranking = [{"meter_id": 1, "kwh": 12.5}, {"meter_id": 2, "kwh": 30.0}, {"meter_id": 3, "kwh": 0.0}]
    session = FakeSession(rows, energy, ranking)

    async def fake_session():
        yield session

    async def fake_list_meters(_session):
        return [_Obj(id=1, name="Prensa 1", gateway_id=1, enabled=True), _Obj(id=2, name="Prensa 2", gateway_id=1, enabled=True),
                _Obj(id=3, name="Forno", gateway_id=2, enabled=True), _Obj(id=4, name="Antigo", gateway_id=2, enabled=False)]

    async def fake_list_gateways(_session):
        return [_Obj(id=1, name="GW1", color="#2a78d6"), _Obj(id=2, name="GW2", color="#1baf7a")]

    monkeypatch.setattr(services, "list_meters", fake_list_meters)
    monkeypatch.setattr(services, "list_gateways", fake_list_gateways)
    app.dependency_overrides[get_session] = fake_session
    app.dependency_overrides[require_auth] = lambda: "test"
    transport = httpx.ASGITransport(app=app)  # não executa o lifespan: não toca no banco nem no coletor
    yield httpx.AsyncClient(transport=transport, base_url="http://t"), session
    app.dependency_overrides.clear()


async def test_history_route_shape(client):
    c, session = client
    r = await c.get("/api/history", params={"metric": "ia", "meter_ids": "1,2", "range": "1h"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["metric"] == "ia" and body["unit"] == "A" and body["from_zero"] is True
    assert body["bucket"] == "5s" and body["source"] == "reading_fast" and body["step_s"] == 5
    assert len(body["t"]) == 2 and body["t"] == sorted(body["t"])
    s1, s2 = body["series"]["1"], body["series"]["2"]
    assert s1["name"] == "Prensa 1" and s1["gateway_id"] == 1
    assert s1["v"] == [10.0, None] and s2["v"] == [None, 11.0]
    sql, params = session.calls[0]
    assert params["ids"] == [1, 2] and params["step"] == 5 and params["frm"].tzinfo is not None
    assert "ia AS v FROM reading_fast" in sql and "avg(v) AS v" in sql


async def test_history_route_energy_discards_lag_seed(client):
    c, session = client
    r = await c.get("/api/history", params={"metric": "kwh", "meter_ids": "1,2", "range": "1h"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["bucket"] == "5min" and body["source"] == "reading_slow"
    assert len(body["t"]) == 1 and body["series"]["1"]["v"] == [1.5] and body["series"]["2"]["v"] == [None]
    assert session.calls[0][1]["efrm"] == session.calls[0][1]["frm"] - timedelta(seconds=300)


async def test_history_route_uses_aggregates_for_long_ranges(client):
    c, session = client
    r = await c.get("/api/history", params={"metric": "vln_avg", "meter_ids": "1", "range": "7d"})
    assert r.status_code == 200 and r.json()["source"] == "agg_fast_1min" and r.json()["bucket"] == "15min"
    assert "FROM agg_fast_1min" in session.calls[0][0]
    r = await c.get("/api/history", params={"metric": "thd_ia", "meter_ids": "1", "range": "30d"})
    assert r.status_code == 200 and r.json()["source"] == "agg_slow_1h" and r.json()["bucket"] == "1h"
    r = await c.get("/api/history", params={"metric": "p_total", "meter_ids": "1", "range": "30d", "bucket": "1min"})
    assert r.status_code == 200 and r.json()["bucket"] == "1min"


async def test_history_route_validation(client):
    c, _ = client
    ok = {"metric": "ia", "meter_ids": "1", "range": "1h"}
    assert (await c.get("/api/history", params={**ok, "meter_ids": "1,2,3,4,5,6,7,8,9"})).status_code == 422
    assert (await c.get("/api/history", params={**ok, "range": "30d", "bucket": "1s"})).status_code == 422
    assert (await c.get("/api/history", params={**ok, "range": "2h"})).status_code == 422
    assert (await c.get("/api/history", params={**ok, "metric": "xpto"})).status_code == 422
    assert (await c.get("/api/history", params={"meter_ids": "1", "range": "1h"})).status_code == 422  # sem metric
    assert (await c.get("/api/history", params={"metric": "ia", "meter_ids": "1"})).status_code == 422
    r = await c.get("/api/history", params={**ok, "meter_ids": "1,77"})
    assert r.status_code == 404 and "77" in r.json()["detail"]


async def test_metrics_route(client):
    c, _ = client
    r = await c.get("/api/metrics")
    assert r.status_code == 200 and len(r.json()) == len(services.METRICS)


async def test_ranking_route_shape(client):
    c, session = client
    r = await c.get("/api/energy/ranking", params={"range": "24h"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["bucket"] == "5min" and body["source"] == "reading_slow"
    # ordem decrescente; medidor sem linha (Forno) entra com 0; desativado sem consumo (Antigo) fica de fora
    assert [m["name"] for m in body["meters"]] == ["Prensa 2", "Prensa 1", "Forno"]
    assert body["meters"][0]["kwh"] == 30.0 and body["meters"][2]["kwh"] == 0.0
    assert body["total_kwh"] == 42.5
    gws = {g["name"]: g for g in body["gateways"]}
    assert gws["GW1"]["kwh"] == 42.5 and gws["GW1"]["meters"] == 2 and gws["GW1"]["color"] == "#2a78d6"
    assert gws["GW2"]["kwh"] == 0.0 and gws["GW2"]["meters"] == 1
    sql, params = session.calls[0]
    assert params["ids"] == [1, 2, 3, 4] and params["step"] == 300.0 and "FROM reading_slow" in sql
    r = await c.get("/api/energy/ranking", params={"range": "30d"})
    assert r.json()["source"] == "agg_energy_1h"
    assert (await c.get("/api/energy/ranking")).status_code == 422


# ----------------------------------------------------------------------------- SQL real (opcional)
@pytest.mark.skipif(not os.getenv("BIC_TEST_DATABASE_URL"), reason="precisa de um SQL Server em BIC_TEST_DATABASE_URL")
async def test_history_sql_mssql():
    """Rollups, consultas do histórico/ranking, gravador (duplicata, status) e retenção contra um SQL Server real.

    Aplica o esquema (init_schema é idempotente) e limpa o que criou. Pode rodar com o coletor ligado no mesmo banco:
    a retenção só é testada com uma linha de 500 dias atrás.
    """
    from sqlalchemy import insert, text
    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from app.db import rollup
    from app.db.models import Gateway, Meter, ReadingFast, ReadingSlow
    from app.db.schema import init_schema
    from app.poller.writer import BatchWriter

    engine = create_async_engine(os.environ["BIC_TEST_DATABASE_URL"])
    await init_schema(engine)
    Session = async_sessionmaker(engine, expire_on_commit=False)
    # "now" alinhado a um limite de 5 min para os buckets de energia ficarem determinísticos
    now = datetime.now(UTC).replace(second=0, microsecond=0)
    now -= timedelta(minutes=now.minute % 5)
    async with Session() as session:
        g = Gateway(name="t-gw", host="127.0.0.1", port=1, color="#123456")
        session.add(g)
        await session.flush()
        m = Meter(gateway_id=g.id, name="t-meter", unit_id=200)
        session.add(m)
        await session.commit()
        gid, mid = g.id, m.id   # o rollback do finally expira os objetos; os ids ficam em variáveis
        try:
            # 2 min de leituras rápidas a 1 s
            await session.execute(insert(ReadingFast), [
                {"ts": now - timedelta(seconds=120 - i), "meter_id": m.id, "p_total": float(i), "pf_total": 0.9, "i_avg": 10.0, "vln_avg": 220.0, "in_": 1.5}
                for i in range(120)])
            # acumulador a cada 30 s por 15 min: 100..114 e depois um reset (0.5, 1.5, ... 14.5); THD constante
            # buckets de 5 min: [now-15, now-10) último 109 | [now-10, now-5) último 4.5 | [now-5, now) último 14.5
            # consumo visível = (4.5: pós-reset) + (14.5 - 4.5) = 14.5 (o 1º bucket não tem anterior)
            kwh = [100 + i for i in range(15)] + [0.5 + i for i in range(15)]
            await session.execute(insert(ReadingSlow), [
                {"ts": now - timedelta(minutes=15) + timedelta(seconds=30 * i), "meter_id": m.id, "kwh_import": float(k), "thd_ia": 3.0, "demand_peak": float(k)}
                for i, k in enumerate(kwh)])
            await session.commit()
            # materializa a janela do teste em todos os agregados e posiciona o watermark no bucket atual
            for agg in rollup.AGGREGATES:
                await rollup.refresh_window(engine, agg, now - timedelta(hours=2), now + timedelta(hours=1))
            await rollup.refresh_all(engine, now=now + timedelta(seconds=1))
            wm = (await session.execute(text("SELECT watermark FROM agg_state WHERE name = 'agg_fast_1min'"))).scalar()
            assert wm.replace(tzinfo=UTC) == now
            n = (await session.execute(text("SELECT COUNT(*) FROM agg_fast_1min WHERE meter_id = :m"), {"m": m.id})).scalar()
            assert n == 2
            frm, to = now - timedelta(minutes=15), now   # exatamente 15 min -> bucket de 1 s
            span = to - frm
            # rápido, bruto, 1 s
            out = await services.meter_history(session, services.METRICS["p_total"], [m.id], frm, to, services.plan_for_metric(services.METRICS["p_total"], span))
            v = out["series"][str(m.id)]["v"]
            assert len(out["t"]) == 120 and v[0] == 0.0 and v[-1] == 119.0 and out["t"][0] == int((now - timedelta(seconds=120)).timestamp())
            # rápido, rollup de 15 min sobre agg_fast_1min
            out = await services.meter_history(session, services.METRICS["in_"], [m.id], frm, to, services.plan_for_metric(services.METRICS["in_"], span, "15min"))
            assert out["source"] == "agg_fast_1min" and any(x == 1.5 for x in out["series"][str(m.id)]["v"])
            # lento, bruto, 1 min
            out = await services.meter_history(session, services.METRICS["thd_ia"], [m.id], frm, to, services.plan_for_metric(services.METRICS["thd_ia"], span))
            assert out["bucket"] == "1min" and 3.0 in out["series"][str(m.id)]["v"]
            # lento, agregado de 1 h com max
            out = await services.meter_history(session, services.METRICS["demand_peak"], [m.id], frm, to, services.plan_for_metric(services.METRICS["demand_peak"], span, "1h"))
            # o bucket de 1 h que começa antes de frm fica de fora, então o máximo visível depende da hora do teste
            vals = [x for x in out["series"][str(m.id)]["v"] if x is not None]
            assert out["source"] == "agg_slow_1h" and vals and max(vals) in (114.0, 14.5)
            # energia: consumo nunca negativo apesar do reset
            out = await services.meter_history(session, services.METRICS["kwh"], [m.id], frm, to, services.plan_for_metric(services.METRICS["kwh"], span))
            e = out["series"][str(m.id)]["v"]
            assert out["bucket"] == "5min" and e == [None, 4.5, 10.0]
            rank = await services.energy_ranking(session, frm, to)
            mine = next(r for r in rank["meters"] if r["meter_id"] == m.id)
            assert abs(mine["kwh"] - 14.5) < 1e-6
            gw = next(gw for gw in rank["gateways"] if gw["gateway_id"] == g.id)
            assert gw["color"] == "#123456" and abs(gw["kwh"] - 14.5) < 1e-6
            # energia pelo agregado de 1 h (30 dias): a cauda bruta a partir do watermark entra no cálculo
            out = await services.meter_history(session, services.METRICS["kwh"], [m.id], now - timedelta(days=30), to, services.plan_for_metric(services.METRICS["kwh"], timedelta(days=30)))
            assert out["source"] == "agg_energy_1d" and out["series"][str(m.id)]["v"][-1] in (None, 14.5, 10.0)
            # gravador: a duplicata é ignorada (IGNORE_DUP_KEY) e o status faz upsert mantendo o que não veio
            w = BatchWriter(engine)
            w.add_fast({"ts": now - timedelta(seconds=1), "meter_id": m.id, "p_total": 999.0})
            w.set_status(m.id, last_ok_at=now, consecutive_failures=0)
            await w.flush()
            w.set_status(m.id, last_error="timeout", last_error_at=now, consecutive_failures=2)
            await w.flush()
            assert w.rows_written == 1 and w.last_error is None
            row = (await session.execute(text("SELECT p_total FROM reading_fast WHERE meter_id = :m AND ts = :ts"),
                                         {"m": m.id, "ts": (now - timedelta(seconds=1)).replace(tzinfo=None)})).scalar()
            assert row == 119.0
            st = (await session.execute(text("SELECT last_ok_at, last_error, consecutive_failures FROM meter_status WHERE meter_id = :m"), {"m": m.id})).one()
            assert st.last_ok_at.replace(tzinfo=UTC) == now and st.last_error == "timeout" and st.consecutive_failures == 2
            # retenção em lotes: só o que é mais velho que o corte
            await session.execute(insert(ReadingFast), [{"ts": now - timedelta(days=500), "meter_id": m.id, "p_total": 1.0}])
            await session.commit()
            assert await rollup.purge_old_rows(engine, "reading_fast", 400, now=now) >= 1
            n = (await session.execute(text("SELECT COUNT(*) FROM reading_fast WHERE meter_id = :m"), {"m": m.id})).scalar()
            assert n == 120
            # views do Power BI respondem (fuso configurado)
            rows = (await session.execute(text("SELECT TOP (1) bucket_local, dia_local FROM v_pbi_energy_1h WHERE meter_id = :m"), {"m": m.id})).all()
            assert rows and rows[0].dia_local is not None
            # views por resolução do relatório: grandezas elétricas e energia na mesma linha (v_pbi_1h/1d) e 5 min das leituras lentas
            rows = (await session.execute(text("SELECT TOP (1) bucket_utc, kwh, p_avg, demand_peak FROM v_pbi_1h WHERE meter_id = :m AND kwh IS NOT NULL"), {"m": m.id})).all()
            assert rows and rows[0].bucket_utc is not None
            rows = (await session.execute(text("SELECT COUNT(*) AS n, SUM(kwh) AS kwh FROM v_pbi_5min WHERE meter_id = :m"), {"m": m.id})).one()
            assert rows.n >= 1
            rows = (await session.execute(text("SELECT TOP (1) bucket_local, kwh FROM v_pbi_1d WHERE meter_id = :m"), {"m": m.id})).all()
            assert rows
        finally:
            await session.rollback()
            for table in ["reading_fast", "reading_slow", "meter_status"] + [a.name for a in rollup.AGGREGATES]:
                await session.execute(text(f"DELETE FROM {table} WHERE meter_id = :m"), {"m": mid})
            await session.execute(text("DELETE FROM meter WHERE id = :m"), {"m": mid})
            await session.execute(text("DELETE FROM gateway WHERE id = :g"), {"g": gid})
            await session.commit()
    await engine.dispose()
