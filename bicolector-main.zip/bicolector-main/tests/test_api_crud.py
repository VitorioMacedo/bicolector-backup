"""CRUD de gateways e medidores pela API JSON (é o que o painel usa), com SQLite em memória."""
from __future__ import annotations

import httpx
import pytest
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.api.deps import require_auth
from app.db.models import Base
from app.db.session import get_session
from app.main import app


@pytest.fixture
async def client():
    engine = create_async_engine("sqlite+aiosqlite://")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Session = async_sessionmaker(engine, expire_on_commit=False)

    async def fake_session():
        async with Session() as s:
            yield s

    app.dependency_overrides[get_session] = fake_session
    app.dependency_overrides[require_auth] = lambda: "test"
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        yield c
    app.dependency_overrides.clear()
    await engine.dispose()


async def test_gateway_and_meter_lifecycle(client):
    r = await client.post("/api/gateways", json={"name": " GW1 ", "host": "10.0.0.5", "port": 502, "fast_block": "full"})
    assert r.status_code == 201, r.text
    g = r.json()
    assert g["name"] == "GW1" and g["enabled"] is True

    r = await client.post("/api/gateways", json={"name": "x", "host": "h", "fast_block": "weird"})
    assert r.status_code == 422

    r = await client.put(f"/api/gateways/{g['id']}", json={"fast_block": "compact", "enabled": False, "port": 5020})
    assert r.status_code == 200 and r.json()["fast_block"] == "compact" and r.json()["enabled"] is False

    r = await client.post("/api/meters", json={"gateway_id": g["id"], "name": "Prensa 1", "unit_id": 1})
    assert r.status_code == 201
    m = r.json()
    r = await client.post("/api/meters", json={"gateway_id": g["id"], "name": "Outra", "unit_id": 1})
    assert r.status_code == 409 and "Prensa 1" in r.json()["detail"]
    r = await client.post("/api/meters", json={"gateway_id": g["id"], "name": "Outra", "unit_id": 300})
    assert r.status_code == 422
    r = await client.post("/api/meters", json={"gateway_id": 999, "name": "Outra", "unit_id": 2})
    assert r.status_code == 404

    r = await client.put(f"/api/meters/{m['id']}", json={"name": "Prensa 1B", "unit_id": 7})
    assert r.status_code == 200 and r.json()["name"] == "Prensa 1B" and r.json()["unit_id"] == 7

    assert (await client.get("/api/meters")).json()[0]["unit_id"] == 7
    assert (await client.delete(f"/api/meters/{m['id']}")).status_code == 204
    assert (await client.get("/api/meters")).json() == []
    assert (await client.delete(f"/api/gateways/{g['id']}")).status_code == 204
    assert (await client.get("/api/gateways")).json() == []


async def test_gateway_color_defaults_and_validation(client):
    from app.services import GATEWAY_PALETTE

    g1 = (await client.post("/api/gateways", json={"name": "A", "host": "h1"})).json()
    g2 = (await client.post("/api/gateways", json={"name": "B", "host": "h2", "color": ""})).json()
    assert g1["color"] == GATEWAY_PALETTE[0] and g2["color"] == GATEWAY_PALETTE[1]
    g3 = (await client.post("/api/gateways", json={"name": "C", "host": "h3", "color": "#ABCDEF"})).json()
    assert g3["color"] == "#abcdef"
    assert (await client.post("/api/gateways", json={"name": "D", "host": "h4", "color": "verde"})).status_code == 422
    r = await client.put(f"/api/gateways/{g1['id']}", json={"color": "#112233"})
    assert r.status_code == 200 and r.json()["color"] == "#112233"
    assert (await client.put(f"/api/gateways/{g1['id']}", json={"color": "red"})).status_code == 422
    page = (await client.get("/partials/meters")).text
    assert "#112233" in page and 'data-color="#abcdef"' in page


async def test_pages_render(client):
    """As páginas HTML carregam com o banco vazio (sem coletor)."""
    for path in ["/", "/meters", "/partials/meters", "/charts", "/settings", "/commands"]:
        r = await client.get(path)
        assert r.status_code == 200, (path, r.text[:200])
        assert "text/html" in r.headers["content-type"]
    page = (await client.get("/meters")).text
    assert "gateway-dlg" in page and "meter-dlg" in page
    assert (await client.get("/partials/status")).status_code == 404  # rota antiga removida
