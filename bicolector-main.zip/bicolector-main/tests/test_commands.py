"""Testa a sequência de comandos (reset) contra um gateway falso que registra as escritas."""
import asyncio

import pytest

from app.modbus import registers as R
from app.modbus.client import ModbusError
from app.modbus.commands import send_command


class FakeGateway:
    def __init__(self, unprotected_result=0, protected_result=0, refuse_unprotected=False, semaphore=62283):
        self.lock = asyncio.Lock()
        self.writes: list[tuple[int, int, list[int]]] = []
        self.unprotected_result = unprotected_result
        self.protected_result = protected_result
        self.refuse_unprotected = refuse_unprotected
        self.semaphore = semaphore

    async def write_registers(self, unit, address0, values):
        if self.refuse_unprotected and address0 in (R.CMD_UNPROTECTED_PASSWORD - 1, R.CMD_UNPROTECTED_COMMAND - 1):
            raise ModbusError("exceção Modbus código 2")
        self.writes.append((unit, address0, list(values)))

    async def read_registers(self, unit, address0, count):
        if address0 == R.CMD_UNPROTECTED_RESULT - 1:
            return [self.unprotected_result]
        if address0 == R.CMD_PROTECTED_RESULT - 1:
            return [self.protected_result]
        if address0 == R.CMD_SEMAPHORE - 1:
            return [self.semaphore]
        raise ModbusError("endereço inesperado")


async def test_unprotected_password_first_layout():
    gw = FakeGateway()
    res = await send_command(gw, 7, 2020, password=0, layout="password_first")
    assert res.success and res.result_code == 0
    assert gw.writes == [(7, R.CMD_UNPROTECTED_PASSWORD - 1, [0, 2020, 0])]


async def test_unprotected_command_first_layout():
    gw = FakeGateway()
    res = await send_command(gw, 3, 1003, layout="command_first")
    assert res.success
    assert gw.writes == [(3, R.CMD_UNPROTECTED_COMMAND - 1, [1003, 0])]


async def test_falls_back_to_semaphore_interface_when_refused():
    gw = FakeGateway(refuse_unprotected=True)
    res = await send_command(gw, 1, 2020)
    assert res.success
    assert "protegida" in res.detail
    assert gw.writes == [(1, R.CMD_PROTECTED_COMMAND - 1, [2020, 62283])]


async def test_falls_back_when_unprotected_result_nonzero():
    gw = FakeGateway(unprotected_result=3001)
    res = await send_command(gw, 1, 2020)
    assert res.success
    assert gw.writes[0][1] == R.CMD_UNPROTECTED_PASSWORD - 1
    assert gw.writes[1][1] == R.CMD_PROTECTED_COMMAND - 1


async def test_reports_failure_when_both_interfaces_fail():
    gw = FakeGateway(unprotected_result=5, protected_result=9)
    res = await send_command(gw, 1, 2020)
    assert not res.success
    assert res.result_code == 9
    assert "sem semáforo: resultado 5" in res.detail and "protegida: resultado 9" in res.detail
