"""Benchmark de campo: mede o tempo real de resposta de cada medidor através de um gateway e
estima o ciclo mínimo alcançável. Rodar na etapa de levantamento, em cada gateway:

    uv run python -m tools.benchmark --host 192.168.0.10 --units 1-10 --rounds 20
    uv run python -m tools.benchmark --host 192.168.0.10 --units 1-10 --block compact --slow

Imprime latência mín/méd/p95/máx por medidor, duração de cada ciclo completo e um veredito
em relação ao intervalo alvo (--target, padrão 1 s).
"""
from __future__ import annotations

import argparse
import asyncio
import statistics
import sys
import time

from app.modbus import registers as R
from app.modbus.client import GatewayClient, ModbusError


def parse_units(spec: str) -> list[int]:
    out: list[int] = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def pct(values: list[float], p: float) -> float:
    if not values:
        return float("nan")
    s = sorted(values)
    k = min(len(s) - 1, max(0, round(p / 100 * (len(s) - 1))))
    return s[k]


async def run(args: argparse.Namespace) -> int:
    units = parse_units(args.units)
    block = R.FAST_BLOCKS[args.block]
    gw = GatewayClient(0, "bench", args.host, args.port, timeout=args.timeout, retries=0)
    if not await gw.connect():
        print(f"não foi possível conectar em {args.host}:{args.port}", file=sys.stderr)
        return 2
    print(f"gateway {args.host}:{args.port} · {len(units)} medidores · bloco {block.name} ({block.count} regs) · {args.rounds} rodadas · alvo {args.target:.2f} s\n")

    lat: dict[int, list[float]] = {u: [] for u in units}
    errors: dict[int, int] = {u: 0 for u in units}
    cycles: list[float] = []
    slow_cost: list[float] = []
    for r in range(args.rounds):
        t0 = time.perf_counter()
        for u in units:
            t1 = time.perf_counter()
            try:
                await gw.read_registers(u, block.address0, block.count)
                lat[u].append((time.perf_counter() - t1) * 1000)
            except ModbusError as exc:
                errors[u] += 1
                if r == 0:
                    print(f"  unit {u}: {exc}")
        cycles.append((time.perf_counter() - t0) * 1000)
        if args.slow:
            u = units[r % len(units)]
            t1 = time.perf_counter()
            try:
                for b in R.SLOW_BLOCKS:
                    await gw.read_registers(u, b.address0, b.count)
                slow_cost.append((time.perf_counter() - t1) * 1000)
            except ModbusError:
                pass
        print(f"rodada {r + 1:>3}: ciclo {cycles[-1]:7.1f} ms", end="\r", flush=True)
    gw.close()
    print(" " * 40, end="\r")

    print(f"{'unit':>5} {'ok':>4} {'erro':>4} {'mín ms':>8} {'méd ms':>8} {'p95 ms':>8} {'máx ms':>8}")
    per_meter_avg: list[float] = []
    for u in units:
        v = lat[u]
        if v:
            per_meter_avg.append(statistics.mean(v))
            print(f"{u:>5} {len(v):>4} {errors[u]:>4} {min(v):8.1f} {statistics.mean(v):8.1f} {pct(v, 95):8.1f} {max(v):8.1f}")
        else:
            print(f"{u:>5} {0:>4} {errors[u]:>4} {'-':>8} {'-':>8} {'-':>8} {'-':>8}")

    avg_cycle = statistics.mean(cycles)
    print(f"\nciclo completo ({len(units)} medidores): mín {min(cycles):.0f} ms · méd {avg_cycle:.0f} ms · p95 {pct(cycles, 95):.0f} ms · máx {max(cycles):.0f} ms")
    if slow_cost:
        print(f"rodada lenta (3 blocos, 1 medidor): méd {statistics.mean(slow_cost):.0f} ms · máx {max(slow_cost):.0f} ms")
    if per_meter_avg:
        m = statistics.mean(per_meter_avg)
        print(f"latência média por medidor: {m:.1f} ms → com N medidores neste barramento o ciclo fica em ~N × {m:.0f} ms")
        budget = args.target * 1000
        headroom = budget - pct(cycles, 95)
        if headroom > 0.25 * budget:
            verdict = "OK com folga"
        elif headroom > 0:
            verdict = "OK, mas apertado (ciclo lento pode não caber; considere o bloco compact)"
        else:
            verdict = "NÃO alcança o alvo: reduza medidores neste gateway, use o bloco compact ou aumente o intervalo"
        print(f"veredito para intervalo de {args.target:.2f} s: {verdict} (p95 do ciclo = {pct(cycles, 95):.0f} ms)")
    return 0


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", required=True)
    ap.add_argument("--port", type=int, default=502)
    ap.add_argument("--units", default="1-10", help="ex.: 1-10 ou 1,2,5-8")
    ap.add_argument("--block", choices=sorted(R.FAST_BLOCKS), default="full")
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--timeout", type=float, default=0.5)
    ap.add_argument("--target", type=float, default=1.0, help="intervalo alvo em segundos")
    ap.add_argument("--slow", action="store_true", help="mede também o custo de uma rodada do ciclo lento")
    args = ap.parse_args()
    sys.exit(asyncio.run(run(args)))


if __name__ == "__main__":
    main()
