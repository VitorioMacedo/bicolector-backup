"""Gera o projeto Power BI (powerbi/bic.pbip): modelo semântico em TMDL (DirectQuery no SQL Server) e
relatório no formato PBIR espelhando a página "Gráficos" do painel: período (presets ou de/até), consumo por
medidor (total, pizza e tiles por gateway, colunas por medidor) e gráfico por grandeza com seletores de grandeza,
resolução, gateways e medidores. A página "Agora" traz a última leitura de cada máquina.

Uso:  uv run python -m tools.pbip_gen [--out powerbi] [--server localhost] [--db bic]

Servidor no formato do SQL Server: "host", "host,1433" ou "host\\instancia".

Abra powerbi/bic.pbip no Power BI Desktop. Na primeira abertura ele pede as credenciais do SQL Server
(usuário somente leitura "powerbi", ver docs/powerbi.md). Servidor e banco são parâmetros do modelo
(Transformar dados -> Editar parâmetros) e podem ser trocados sem regerar o projeto.

Tudo em powerbi/ sai deste arquivo (ids determinísticos): mude aqui e regere, não edite o projeto à mão.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NS = uuid.UUID("5a1d2d6e-7c8b-4a2e-9e4f-bic000000001".replace("bic", "b1c"))

PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
ORANGE, BLACK, INK, MUTED, LINE, BG = "#f26b1d", "#0b0b0b", "#111827", "#6b7280", "#e5e7eb", "#f5f5f4"
NEUTRAL = "#9ca3af"

SCHEMA = "https://developer.microsoft.com/json-schemas/fabric"
BASE_THEME = "Fluent2-CY26SU09"
VERSIONS = {"visual": "2.13.0", "report": "3.4.0", "page": "2.3.1"}


def tag(*parts: str) -> str:
    """lineageTag determinístico (regerar o projeto não muda os ids)."""
    return str(uuid.uuid5(NS, "|".join(parts)))


def hex20(*parts: str) -> str:
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:20]


# ----------------------------------------------------------------------------- modelo (TMDL)
# (nome da tabela no modelo, view no SQL Server, colunas [(nome, tipo, formato, oculta)], medidas [(nome, DAX, formato)])
D, DT, I, S, B = "double", "dateTime", "int64", "string", "boolean"
FMT_TS, FMT_DAY = "dd/MM/yyyy HH:mm", "dd/MM/yyyy"

HUB = "Medidores"  # tabela que recebe todas as medidas do relatório


def _c(name: str, fmt: str, hidden: bool = True) -> tuple:
    return (name, D, fmt, hidden)


# colunas das views por resolução (todas ocultas: o relatório usa só medidas)
_P = [_c("p_avg", "#,0.00"), _c("p_min", "#,0.00"), _c("p_max", "#,0.00")]
_QS = [_c("q_avg", "#,0.00"), _c("s_avg", "#,0.00")]
_I = [_c("i_avg", "#,0.0"), _c("i_max", "#,0.0")]
_IABC = [_c("ia_avg", "#,0.0"), _c("ib_avg", "#,0.0"), _c("ic_avg", "#,0.0")]
_V = [_c("vln_avg", "#,0.0"), _c("vln_min", "#,0.0"), _c("vln_max", "#,0.0")]
_VLL = [_c("vll_avg", "#,0.0")]
_PF = [_c("pf_avg", "0.000"), _c("pf_min", "0.000")]
_SAMPLES = [("samples", I, "0", True)]
_KWH = [_c("kwh", "#,0.00"), _c("kwh_acumulado", "#,0.0")]
_DEMAND = [_c("demand_peak", "#,0.00")]
_FREQ = [_c("freq_avg", "0.00")]
_THD = [_c(c, "0.0") for c in ("thd_ia", "thd_ib", "thd_ic", "thd_van", "thd_vbn", "thd_vcn")]


def _time_cols(fmt: str) -> list[tuple]:
    return [("bucket_local", DT, fmt, False), ("bucket_utc", DT, FMT_TS, True), ("dia_local", DT, FMT_DAY, True), ("meter_id", I, "0", True)]


# Resoluções do seletor "Resolução", na ordem do field parameter (o índice é o valor de 'Resolução ordem').
GRAINS: list[tuple[str, str, str, list[tuple]]] = [
    # (rótulo, tabela do modelo, view, colunas)
    ("1 min", "Leituras 1 min", "v_pbi_1min", _time_cols(FMT_TS) + _P + _QS + _I + _IABC + _V + _VLL + _PF + _SAMPLES),
    ("5 min", "Leituras 5 min", "v_pbi_5min", _time_cols(FMT_TS) + _P + _QS + _I + _V + _VLL + _PF + _SAMPLES + _KWH),
    ("15 min", "Leituras 15 min", "v_pbi_15min", _time_cols(FMT_TS) + _P + _QS + _I + _V + _PF + _SAMPLES),
    ("1 h", "Leituras 1 h", "v_pbi_1h", _time_cols(FMT_TS) + _P + _QS + _I + _V + _PF + _SAMPLES + _KWH + _DEMAND + _FREQ + _THD),
    ("1 dia", "Leituras 1 dia", "v_pbi_1d", _time_cols(FMT_DAY) + _P + _I + _V + _PF + _SAMPLES + _KWH + _DEMAND),
]
GRAIN_TABLES = [g[1] for g in GRAINS]
DEFAULT_GRAIN = "15 min"
DEFAULT_GRAIN_TABLE = next(g[1] for g in GRAINS if g[0] == DEFAULT_GRAIN)

# Grandezas do seletor "Grandeza": (rótulo = nome da medida, formato, agregador, coluna). A medida existe em cada
# resolução cuja view tem a coluna; nas demais devolve BLANK() (o gráfico fica vazio e o subtítulo explica).
GRANDEZAS: list[tuple[str, str, str, str]] = [
    ("Consumo de energia (kWh)", "#,0.00", "SUM", "kwh"),
    ("Potência ativa (kW)", "#,0.00", "AVERAGE", "p_avg"),
    ("Potência reativa (kvar)", "#,0.00", "AVERAGE", "q_avg"),
    ("Potência aparente (kVA)", "#,0.00", "AVERAGE", "s_avg"),
    ("Fator de potência", "0.000", "AVERAGE", "pf_avg"),
    ("Corrente média (A)", "#,0.0", "AVERAGE", "i_avg"),
    ("Tensão L-N média (V)", "#,0.0", "AVERAGE", "vln_avg"),
    ("Tensão L-L média (V)", "#,0.0", "AVERAGE", "vll_avg"),
    ("Demanda de pico (kW)", "#,0.00", "MAX", "demand_peak"),
    ("Frequência (Hz)", "0.00", "AVERAGE", "freq_avg"),
    ("Energia ativa acumulada (kWh)", "#,0.0", "MAX", "kwh_acumulado"),
]
DEFAULT_GRANDEZA = "Potência ativa (kW)"

# Presets de período (iguais aos botões da página web); o padrão é 24 h.
PERIODS: list[tuple[str, int]] = [("15 min", 15), ("1 h", 60), ("6 h", 360), ("24 h", 1440), ("7 dias", 10080), ("30 dias", 43200)]
DEFAULT_PERIOD = "24 h"
MAX_METERS = 8  # a página web limita a 8 medidores no gráfico por grandeza; aqui vira filtro Top N por kWh


def _tbl(name: str) -> str:
    return "'" + name + "'"


def grain_has(table: str, column: str) -> bool:
    cols = next(g[3] for g in GRAINS if g[1] == table)
    return any(c[0] == column for c in cols)


def grandeza_measure(label: str, agg: str, column: str) -> str:
    """SWITCH pela resolução escolhida: cada ramo agrega a coluna na tabela daquele grão, limitada ao período."""
    branches = []
    for idx, (_, table, _, _) in enumerate(GRAINS):
        if grain_has(table, column):
            branches.append(f"{idx}, CALCULATE({agg}({_tbl(table)}[{column}]), {_tbl(table)}[bucket_utc] >= t0)")
    default_idx = next(i for i, g in enumerate(GRAINS) if g[0] == DEFAULT_GRAIN)
    return "\n".join([
        f"VAR r = SELECTEDVALUE('Resolução'[Resolução ordem], {default_idx})",
        "VAR t0 = [Início UTC]",
        f"RETURN IF([Posição no ranking] <= {MAX_METERS}, SWITCH(r,",
        *[f"\t{b}," for b in branches],
        "\tBLANK()))",
    ])


def grandeza_grains(column: str) -> str:
    return ", ".join(g[0] for g in GRAINS if grain_has(g[1], column))


def _kwh_branch(table: str) -> str:
    return f"CALCULATE(SUM({_tbl(table)}[kwh]), {_tbl(table)}[bucket_utc] >= t0)"


# Medidas do relatório (todas em Medidores). O período relativo entra como filtro bucket_utc >= agora - minutos; se o
# usuário usar o seletor de/até (Calendário), o preset é ignorado e vale a relação por dia_local.
REPORT_MEASURES: list[tuple[str, str, str]] = [
    ("Início UTC", "IF(ISFILTERED('Calendário'[dia]), DATE(1900, 1, 1), UTCNOW() - DIVIDE(SELECTEDVALUE('Período'[minutos], 1440), 1440))", "dd/MM/yyyy HH:mm"),
    ("Minutos do período", "IF(ISFILTERED('Calendário'[dia]), DATEDIFF(MIN('Calendário'[dia]), MAX('Calendário'[dia]), MINUTE) + 1440, SELECTEDVALUE('Período'[minutos], 1440))", "0"),
    # mesma escolha de fonte do ranking do painel (services.ranking_plan): <= 7 d em 5 min, <= 90 d por hora, depois por dia
    ("kWh no período", "\n".join([
        "VAR mins = [Minutos do período]",
        "VAR t0 = [Início UTC]",
        "RETURN SWITCH(TRUE(),",
        f"\tmins <= 10080, {_kwh_branch('Leituras 5 min')},",
        f"\tmins <= 129600, {_kwh_branch('Leituras 1 h')},",
        f"\t{_kwh_branch('Leituras 1 dia')})",
    ]), "#,0.00"),
    ("% do total", "DIVIDE([kWh no período], CALCULATE([kWh no período], ALLSELECTED('Medidores')))", "0.0 %"),
    ("Nº medidores", "CALCULATE(DISTINCTCOUNT('Medidores'[meter_id]), 'Medidores'[enabled] = TRUE())", "0"),
    ("Cor do gateway", f'IF(ISBLANK([kWh no período]), BLANK(), COALESCE(MIN(\'Medidores\'[gateway_color]), "{NEUTRAL}"))', None),
    # ranking do medidor no período ignorando o eixo de tempo do gráfico: as grandezas só são desenhadas para os
    # MAX_METERS maiores consumidores entre os medidores selecionados (limite "até 8" da página web)
    # (só a coluna do eixo: REMOVEFILTERS na tabela inteira também soltaria o filtro de medidor, que chega pela relação)
    ("kWh total do período", "CALCULATE([kWh no período], " + ", ".join(f"REMOVEFILTERS({_tbl(t)}[bucket_local])" for t in GRAIN_TABLES) + ")", "#,0.00"),
    ("Posição no ranking", "RANKX(ALLSELECTED('Medidores'[machine]), [kWh total do período], , DESC, DENSE)", "0"),
] + [(label, grandeza_measure(label, agg, column), fmt) for label, fmt, agg, column in GRANDEZAS]

TABLES = [
    (HUB, "v_meter", [
        ("meter_id", I, "0", True), ("machine", S, None, False), ("unit_id", I, "0", False),
        ("enabled", B, None, False), ("gateway_id", I, "0", True), ("gateway", S, None, False), ("gateway_color", S, None, True),
    ], REPORT_MEASURES),
    ("Calendário", "v_pbi_calendario", [
        ("dia", DT, FMT_DAY, False), ("dia_semana", I, "0", False), ("mes", S, None, False),
    ], []),
    *[(table, view, cols, []) for _, table, view, cols in GRAINS],
    ("Agora", "v_pbi_agora", [
        ("meter_id", I, "0", True), ("machine", S, None, False), ("gateway", S, None, False), ("leitura_local", DT, "dd/MM HH:mm:ss", False),
        ("p_total", D, "#,0.00", False), ("q_total", D, "#,0.00", False), ("s_total", D, "#,0.00", False), ("pf_total", D, "0.000", False),
        ("i_avg", D, "#,0.0", False), ("vln_avg", D, "#,0.0", False), ("vll_avg", D, "#,0.0", False), ("freq", D, "0.00", False),
        ("kwh_import", D, "#,0.0", False), ("demand_present", D, "#,0.00", False), ("demand_peak", D, "#,0.00", False),
    ], [
        ("kW total agora", "SUM('Agora'[p_total])", "#,0.00"),
        ("kWh acumulado total", "SUM('Agora'[kwh_import])", "#,0.0"),
        ("Medidores com leitura", "COUNTROWS(FILTER('Agora', NOT ISBLANK('Agora'[p_total])))", "0"),
    ]),
]

# (tabela muitos, coluna, tabela um, coluna)
RELATIONSHIPS = [(t, "meter_id", HUB, "meter_id") for t in GRAIN_TABLES] + [("Agora", "meter_id", HUB, "meter_id")] + \
                [(t, "dia_local", "Calendário", "dia") for t in GRAIN_TABLES]


def q(name: str) -> str:
    """Nome TMDL: entre aspas simples se tiver espaço ou caractere especial."""
    return "'" + name.replace("'", "''") + "'" if any(c in name for c in " .=:'()%") else name


def measure_tmdl(table: str, mname: str, dax: str, fmt: str | None) -> list[str]:
    if "\n" in dax:
        out = [f"\tmeasure {q(mname)} ="] + ["\t\t\t" + line for line in dax.splitlines()]
    else:
        out = [f"\tmeasure {q(mname)} = {dax}"]
    if fmt:
        out.append(f"\t\tformatString: {fmt}")
    out += [f"\t\tlineageTag: {tag('measure', table, mname)}", ""]
    return out


def table_tmdl(name: str, view: str, columns, measures) -> str:
    out = [f"table {q(name)}", f"\tlineageTag: {tag('table', name)}", ""]
    for mname, dax, fmt in measures:
        out += measure_tmdl(name, mname, dax, fmt)
    for cname, dtype, fmt, hidden in columns:
        out.append(f"\tcolumn {q(cname)}")
        out.append(f"\t\tdataType: {dtype}")
        if hidden:
            out.append("\t\tisHidden")
        if fmt:
            out.append(f"\t\tformatString: {fmt}")
        out.append(f"\t\tlineageTag: {tag('column', name, cname)}")
        out.append("\t\tsummarizeBy: none")
        out.append(f"\t\tsourceColumn: {cname}")
        out.append("")
        out.append("\t\tannotation SummarizationSetBy = User")
        out.append("")
    out += [
        f"\tpartition {q(name)} = m",
        "\t\tmode: directQuery",
        "\t\tsource =",
        "\t\t\tlet",
        "\t\t\t\tFonte = Sql.Database(Servidor, Banco, [CreateNavigationProperties = false]),",
        f'\t\t\t\tDados = Fonte{{[Schema = "dbo", Item = "{view}"]}}[Data]',
        "\t\t\tin",
        "\t\t\t\tDados",
        "",
        "\tannotation PBI_ResultType = Table",
        "",
    ]
    return "\n".join(out)


def _calc_column(table: str, cname: str, source: str, hidden: bool = False, fmt: str | None = None,
                 sort_by: str | None = None, extra: list[str] | None = None) -> list[str]:
    out = [f"\tcolumn {q(cname)}"]
    if hidden:
        out.append("\t\tisHidden")
    if fmt:
        out.append(f"\t\tformatString: {fmt}")
    out += [f"\t\tlineageTag: {tag('column', table, cname)}", "\t\tsummarizeBy: none", f"\t\tsourceColumn: {source}"]
    if sort_by:
        out.append(f"\t\tsortByColumn: {q(sort_by)}")
    out.append("")
    for line in extra or []:
        out.append(line)
    out += ["\t\tannotation SummarizationSetBy = Automatic", ""]
    return out


def field_parameter_tmdl(name: str, items: list[tuple[str, str]]) -> str:
    """Field parameter (seletor de campos): tabela calculada no formato que o Power BI Desktop grava.
    items = [(rótulo, referência NAMEOF), ...]; a ordem da lista é a ordem no seletor."""
    fields, order = f"{name} campo", f"{name} ordem"
    rows = ",\n".join(f'\t\t\t\t\t("{label}", NAMEOF({ref}), {i})' for i, (label, ref) in enumerate(items))
    out = [f"table {q(name)}", f"\tlineageTag: {tag('table', name)}", ""]
    out += _calc_column(name, name, "[Value1]", sort_by=order,
                        extra=["\t\trelatedColumnDetails", f"\t\t\tgroupByColumn: {q(fields)}", ""])
    out += _calc_column(name, fields, "[Value2]", hidden=True, sort_by=order,
                        extra=["\t\textendedProperty ParameterMetadata =", "\t\t\t\t{", '\t\t\t\t  "version": 3,', '\t\t\t\t  "kind": 2', "\t\t\t\t}", ""])
    out += _calc_column(name, order, "[Value3]", hidden=True, fmt="0")
    out += [f"\tpartition {q(name)} = calculated", "\t\tmode: import", "\t\tsource =", "\t\t\t\t{", rows, "\t\t\t\t}", ""]
    return "\n".join(out)


def periodo_tmdl() -> str:
    rows = ", ".join(f'{{"{label}", {i + 1}, {minutes}}}' for i, (label, minutes) in enumerate(PERIODS))
    out = ["table Período", f"\tlineageTag: {tag('table', 'Período')}", ""]
    out += _calc_column("Período", "Período", "[Período]", sort_by="ordem")
    out += _calc_column("Período", "ordem", "[ordem]", hidden=True, fmt="0")
    out += _calc_column("Período", "minutos", "[minutos]", hidden=True, fmt="0")
    out += ["\tpartition Período = calculated", "\t\tmode: import", "\t\tsource =",
            f'\t\t\t\tDATATABLE("Período", STRING, "ordem", INTEGER, "minutos", INTEGER, {{{rows}}})', ""]
    return "\n".join(out)


CALC_TABLES: list[tuple[str, str]] = [
    ("Período", periodo_tmdl()),
    ("Grandeza", field_parameter_tmdl("Grandeza", [(label, f"{_tbl(HUB)}[{label}]") for label, _, _, _ in GRANDEZAS])),
    ("Resolução", field_parameter_tmdl("Resolução", [(label, f"{_tbl(table)}[bucket_local]") for label, table, _, _ in GRAINS])),
]


def model_tmdl() -> str:
    order = json.dumps(["Servidor", "Banco"] + [t[0] for t in TABLES], ensure_ascii=False)
    out = [
        "model Model",
        "\tculture: pt-BR",
        "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
        "\tsourceQueryCulture: en-US",
        "\tvalueFilterBehavior: independent",
        "\tdataAccessOptions",
        "\t\tlegacyRedirects",
        "\t\treturnErrorValuesAsNull",
        "",
        "annotation __PBI_TimeIntelligenceEnabled = 0",
        "",
        f"annotation PBI_QueryOrder = {order}",
        "",
        'annotation PBI_ProTooling = ["DevMode"]',
        "",
    ]
    out += [f"ref table {q(t[0])}" for t in TABLES]
    out += [f"ref table {q(name)}" for name, _ in CALC_TABLES]
    out += ["", "ref cultureInfo pt-BR", ""]
    return "\n".join(out)


def expressions_tmdl(server: str, db: str) -> str:
    return "\n".join([
        f'expression Servidor = "{server}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
        f"\tlineageTag: {tag('expr', 'Servidor')}",
        "",
        "\tannotation PBI_ResultType = Text",
        "",
        f'expression Banco = "{db}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]',
        f"\tlineageTag: {tag('expr', 'Banco')}",
        "",
        "\tannotation PBI_ResultType = Text",
        "",
    ])


def relationships_tmdl() -> str:
    out = []
    for ft, fc, tt, tc in RELATIONSHIPS:
        # as views já fazem JOIN meter e o calendário cobre todos os dias; sem isto o DirectQuery mostra "(Em branco)" nos segmentadores
        out += [f"relationship {tag('rel', ft, fc, tt, tc)}", "\trelyOnReferentialIntegrity", f"\tfromColumn: {q(ft)}.{q(fc)}", f"\ttoColumn: {q(tt)}.{q(tc)}", ""]
    return "\n".join(out)


# ----------------------------------------------------------------------------- relatório (PBIR)
def col(entity: str, prop: str) -> dict:
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def meas(entity: str, prop: str) -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def proj(field: dict, entity: str, prop: str, active: bool = False) -> dict:
    p = {"field": field, "queryRef": f"{entity}.{prop}", "nativeQueryRef": prop}
    if active:
        p["active"] = True
    return p


def literal(value) -> dict:
    if isinstance(value, bool):
        v = "true" if value else "false"
    elif isinstance(value, (int, float)):
        v = f"{value}D"  # é o que o Desktop grava para números e enumerações (ex.: orientation 1D)
    else:
        v = "'" + str(value).replace("'", "''") + "'"
    return {"expr": {"Literal": {"Value": v}}}


def props(**kw) -> dict:
    """{'properties': {chave: literal(valor)}} (valores já no formato expr passam direto)."""
    return {"properties": {k: (v if isinstance(v, dict) and ("expr" in v or "solid" in v) else literal(v)) for k, v in kw.items()}}


def color_by(measure: tuple[str, str]) -> dict:
    """Cor do ponto de dados por campo (formatação condicional "valor de campo"): medida que devolve '#rrggbb'."""
    return {"dataPoint": [{"properties": {"fill": {"solid": {"color": {"expr": meas(*measure)}}}},
                           "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}]}}]}


def container(name: str, x: float, y: float, w: float, h: float, visual: dict, z: int = 0, title: str | None = None,
              subtitle: str | None = None, filters: list[dict] | None = None) -> dict:
    out = {
        "$schema": f"{SCHEMA}/item/report/definition/visualContainer/{VERSIONS['visual']}/schema.json",
        "name": name,
        "position": {"x": x, "y": y, "z": z, "height": h, "width": w, "tabOrder": z},
        "visual": visual,
    }
    if title:
        vco = visual.setdefault("visualContainerObjects", {})
        vco["title"] = [props(text=title, show=True)]
        # sem subtítulo o Desktop mostra o "X por Y e Z" automático
        vco["subTitle"] = [props(text=subtitle, show=True)] if subtitle else [props(show=False)]
    if filters:
        out["filterConfig"] = {"filters": filters}
    return out


def sort_by(field: dict, direction: str = "Ascending") -> dict:
    return {"sort": [{"field": field, "direction": direction}], "isDefaultSort": True}


def param_role(field: dict, parameter: tuple[str, str], display_name: str | None = None, active: bool = False) -> dict:
    """Papel (eixo/valor) alimentado por um field parameter: a projeção é o campo resolvido pela seleção padrão e
    fieldParameters diz que ela veio do parâmetro (o Desktop grava assim; a seleção do segmentador troca o campo)."""
    p = proj(field, *_ref(field), active=active)
    if display_name:
        p["displayName"] = display_name
    return {"projections": [p], "fieldParameters": [{"parameterExpr": col(*parameter), "index": 0, "length": 1}]}


def chart(vtype: str, cat: dict, y: dict, series: dict | None, title: str, name: str, x, yy, w, h, z,
          sort: dict | None = None, objects: dict | None = None, subtitle: str | None = None, filters=None,
          cat_param: tuple[str, str] | None = None, y_param: tuple[str, str] | None = None, cat_label: str | None = None) -> dict:
    """Gráfico com eixo (Category), valor (Y) e série opcional; cat_param / y_param = field parameter que alimenta o papel."""
    qs = {
        "Category": param_role(cat, cat_param, cat_label, active=True) if cat_param else {"projections": [proj(cat, *_ref(cat), active=True)]},
        "Y": param_role(y, y_param) if y_param else {"projections": [proj(y, *_ref(y))]},
    }
    if series:
        qs["Series"] = {"projections": [proj(series, *_ref(series))]}
    visual = {
        "visualType": vtype,
        "query": {"queryState": qs, "sortDefinition": sort or sort_by(cat)},
        "objects": {"legend": [props(show=series is not None, position="Top")], **(objects or {})},
        "drillFilterOtherVisuals": True,
    }
    return container(name, x, yy, w, h, visual, z, title, subtitle, filters)


def _ref(field: dict) -> tuple[str, str]:
    inner = next(iter(field.values()))
    return inner["Expression"]["SourceRef"]["Entity"], inner["Property"]


def selection_filter(entity: str, prop: str, value: str, display: tuple[str, str] | None = None) -> dict:
    """Valor pré-selecionado de um segmentador (é o que o Desktop grava em general.filter ao escolher um item).
    Num field parameter a condição vai na coluna-chave oculta e display = (coluna visível, rótulo) entra como anotação."""
    lit = {"Literal": {"Value": "'" + value.replace("'", "''") + "'"}}
    where = {"Condition": {"In": {"Expressions": [{"Column": {"Expression": {"SourceRef": {"Source": "t"}}, "Property": prop}}], "Values": [[lit]]}}}
    if display:
        where["Annotations"] = {"filterExpressionMetadata": {
            "expressions": [col(entity, display[0])],
            "decomposedIdentities": {"values": [[{"0": [lit]}]], "columns": [{"value": col(entity, prop)}]},
            "valueMap": [{"0": display[1]}]}}
    return {"filter": {"Version": 2, "From": [{"Name": "t", "Entity": entity, "Type": 0}], "Where": [where]}}


def slicer(field: tuple[str, str], mode: str, title: str, name: str, x, y, w, h, z, single: bool = False,
           horizontal: bool = False, default: str | None = None, default_field: tuple[str, str] | None = None, default_label: str | None = None) -> dict:
    """default = valor pré-selecionado; num field parameter a seleção é gravada na coluna-chave oculta (default_field)
    com o NAMEOF do campo, porque a coluna visível faz parte de uma chave composta."""
    general: dict = {}
    if horizontal:
        general["orientation"] = literal(1)
    if default:
        general["filter"] = selection_filter(*(default_field or field), default, display=(field[1], default_label) if default_field else None)
    objects: dict = {"data": [props(mode=mode)]}
    if general:
        objects["general"] = [{"properties": general}]
    if single:
        objects["selection"] = [props(singleSelect=True, strictSingleSelect=True, selectAllCheckboxEnabled=False)]
    visual = {
        "visualType": "slicer",
        "query": {"queryState": {"Values": {"projections": [proj(col(*field), *field, active=True)]}}},
        "objects": objects,
    }
    return container(name, x, y, w, h, visual, z, title)


def card(measure: tuple[str, str], title: str, name: str, x, y, w, h, z) -> dict:
    visual = {
        "visualType": "cardVisual",
        "query": {"queryState": {"Data": {"projections": [proj(meas(*measure), *measure)]}}},
        "drillFilterOtherVisuals": True,
    }
    # o cardVisual já mostra o nome da medida como rótulo; sem título no contêiner para não duplicar
    return container(name, x, y, w, h, visual, z, None)


def table_visual(fields: list[dict], title: str, name: str, x, y, w, h, z, sort: dict | None = None, subtitle: str | None = None) -> dict:
    visual = {
        "visualType": "tableEx",
        "query": {"queryState": {"Values": {"projections": [proj(f, *_ref(f)) for f in fields]}}},
        "drillFilterOtherVisuals": True,
    }
    if sort:
        visual["query"]["sortDefinition"] = sort
    return container(name, x, y, w, h, visual, z, title, subtitle)


def header(text: str, name: str, w: float) -> dict:
    """Faixa preta com o título da página (identidade laranja/preto/branco)."""
    visual = {
        "visualType": "textbox",
        "objects": {"general": [{"properties": {"paragraphs": [{"textRuns": [{"value": text, "textStyle": {"fontWeight": "bold", "fontSize": "16pt", "color": "#FFFFFF"}}]}]}}]},
        "visualContainerObjects": {"background": [{"properties": {"show": literal(True), "color": {"solid": {"color": literal(BLACK)}}, "transparency": literal(0)}}]},
        "drillFilterOtherVisuals": True,
    }
    return container(name, 0, 0, w, 44, visual, 100)


W, M = 1280, 12


def page_refresh(iso_duration: str) -> dict:
    """Atualização automática de página (só existe em DirectQuery). Duração ISO 8601: PT10S, PT1M, PT5M…
    No Power BI Service, workspaces Pro/compartilhados limitam a 30 min; capacidade Fabric/Premium permite até 1 s."""
    return {"pageRefresh": [{"properties": {"show": literal(True), "refreshType": literal("APR"), "duration": literal(iso_duration)}}]}


def page_json(pname: str, title: str, height: int, refresh: str) -> dict:
    return {"$schema": f"{SCHEMA}/item/report/definition/page/2.1.0/schema.json", "name": pname, "displayName": title,
            "displayOption": "FitToPage", "height": height, "width": W, "objects": page_refresh(refresh)}


def page_charts(pname: str, tz: str, refresh: str) -> tuple[dict, list[dict]]:
    """Página "Gráficos": espelho da página web (período, consumo por medidor com pizza/tiles por gateway, gráfico por grandeza)."""
    H = 900
    page = page_json(pname, "Gráficos", H, refresh)
    kwh = meas(HUB, "kWh no período")
    labels_on = {"labels": [props(show=True)]}
    grain_help = " · ".join(f"{label}: {grandeza_grains(column)}" for label, _, _, column in GRANDEZAS if grandeza_grains(column) != grandeza_grains("p_avg"))
    y1, sh = 56, 84          # linha 1 de filtros
    y2 = y1 + sh + M         # linha 2 de filtros
    y3 = y2 + sh + M         # consumo por medidor: total, pizza, tiles
    h3 = 220
    y4 = y3 + h3 + M         # colunas kWh por medidor
    h4 = 190
    y5 = y4 + h4 + M         # gráfico por grandeza
    h5 = H - y5 - M
    visuals = [
        header(f"bic · Gráficos · horário {tz}", hex20(pname, "header"), W),
        # filtros (a página web: período 15m…30d ou de/até; grandeza; resolução; gateways; medidores)
        slicer(("Período", "Período"), "Basic", "Período", hex20(pname, "slicer-period"), M, y1, 400, sh, 1, single=True, horizontal=True, default=DEFAULT_PERIOD),
        slicer(("Calendário", "dia"), "Between", "ou de / até (dias)", hex20(pname, "slicer-date"), 424, y1, 250, sh, 2),
        slicer(("Grandeza", "Grandeza"), "Dropdown", "Grandeza", hex20(pname, "slicer-grandeza"), 686, y1, 300, sh, 3, single=True,
               default=f"{_tbl(HUB)}[{DEFAULT_GRANDEZA}]", default_field=("Grandeza", "Grandeza campo"), default_label=DEFAULT_GRANDEZA),
        slicer(("Resolução", "Resolução"), "Basic", "Resolução", hex20(pname, "slicer-grain"), 998, y1, W - M - 998, sh, 4, single=True, horizontal=True,
               default=f"{_tbl(DEFAULT_GRAIN_TABLE)}[bucket_local]", default_field=("Resolução", "Resolução campo"), default_label=DEFAULT_GRAIN),
        slicer((HUB, "gateway"), "Basic", "Gateways", hex20(pname, "slicer-gateway"), M, y2, 628, sh, 5, horizontal=True),
        slicer((HUB, "machine"), "Dropdown", "Medidores", hex20(pname, "slicer-meter"), 652, y2, W - M - 652, sh, 6),
        # consumo por medidor
        card((HUB, "kWh no período"), "kWh no total", hex20(pname, "card-total"), M, y3, 200, h3, 7),
        chart("pieChart", col(HUB, "gateway"), kwh, None, "kWh por gateway", hex20(pname, "pie-gateway"), 224, y3, 400, h3, 8,
              sort=sort_by(kwh, "Descending"),
              objects={"labels": [props(show=True, labelStyle="Data value, percent of total", position="outside")],
                       "legend": [props(show=True, position="Right")], **color_by((HUB, "Cor do gateway"))},
              subtitle="soma do consumo dos medidores de cada gateway no período"),
        table_visual([col(HUB, "gateway"), kwh, meas(HUB, "Nº medidores"), meas(HUB, "% do total")], "Gateways", hex20(pname, "tiles-gateway"),
                     636, y3, W - M - 636, h3, 9, sort=sort_by(kwh, "Descending"), subtitle="kWh no período, medidores ativos e participação no total"),
        chart("columnChart", col(HUB, "machine"), kwh, None, "Consumo por medidor", hex20(pname, "kwh-meter"), M, y4, W - 2 * M, h4, 10,
              sort=sort_by(kwh, "Descending"), objects={**labels_on, **color_by((HUB, "Cor do gateway"))},
              subtitle="kWh no período, do maior para o menor; clique numa coluna para filtrar o gráfico abaixo"),
        # gráfico por grandeza: eixo e valor vêm dos seletores (field parameters); só os maiores consumidores entram
        chart("lineChart", col(DEFAULT_GRAIN_TABLE, "bucket_local"), meas(HUB, DEFAULT_GRANDEZA), col(HUB, "machine"), "Gráfico por grandeza",
              hex20(pname, "generic"), M, y5, W - 2 * M, h5, 11, objects={"labels": [props(show=True, labelDensity=100)]},
              subtitle=f"uma linha por medidor, só os {MAX_METERS} maiores consumidores do período entre os selecionados · resoluções disponíveis: {grain_help}",
              cat_param=("Resolução", "Resolução"), cat_label=DEFAULT_GRAIN, y_param=("Grandeza", "Grandeza")),
    ]
    return page, visuals


def page_now(pname: str, tz: str, refresh: str) -> tuple[dict, list[dict]]:
    page = page_json(pname, "Agora", 720, refresh)
    cols = ["machine", "gateway", "leitura_local", "p_total", "i_avg", "vln_avg", "vll_avg", "pf_total", "freq", "kwh_import", "demand_present", "demand_peak"]
    visuals = [
        header(f"bic · Leitura atual por máquina · horário {tz}", hex20(pname, "header"), W),
        card(("Agora", "kW total agora"), "kW total agora", hex20(pname, "card-kw"), M, 56, 300, 90, 1),
        card(("Agora", "kWh acumulado total"), "kWh acumulado (todos os medidores)", hex20(pname, "card-kwh"), M + 312, 56, 300, 90, 2),
        card(("Agora", "Medidores com leitura"), "Medidores com leitura", hex20(pname, "card-n"), M + 624, 56, 300, 90, 3),
        table_visual([col("Agora", c) for c in cols], "Última leitura de cada máquina", hex20(pname, "table"), M, 158, W - 2 * M, 720 - 158 - M, 4),
    ]
    return page, visuals


def theme() -> dict:
    return {
        "name": "bic",
        "dataColors": PALETTE,
        "background": "#FFFFFF", "foreground": INK, "tableAccent": ORANGE,
        "firstLevelElements": INK, "secondLevelElements": MUTED, "thirdLevelElements": LINE, "fourthLevelElements": NEUTRAL,
        "secondaryBackground": BG,
        "good": "#15803d", "neutral": ORANGE, "bad": "#b91c1c",
        "maximum": ORANGE, "center": "#fff1e8", "minimum": LINE, "null": NEUTRAL,
        "textClasses": {
            "callout": {"fontSize": 22, "fontFace": "Segoe UI Semibold", "color": INK},
            "title": {"fontSize": 12, "fontFace": "Segoe UI Semibold", "color": INK},
            "header": {"fontSize": 12, "fontFace": "Segoe UI Semibold", "color": INK},
            "label": {"fontSize": 10, "fontFace": "Segoe UI", "color": INK},
        },
        "visualStyles": {
            "*": {"*": {
                "background": [{"show": True, "color": {"solid": {"color": "#FFFFFF"}}, "transparency": 0}],
                "border": [{"show": True, "color": {"solid": {"color": LINE}}, "radius": 10}],
                "dropShadow": [{"show": False}],
                "title": [{"show": True, "fontColor": {"solid": {"color": BLACK}}, "bold": True, "fontSize": 12}],
                "subTitle": [{"fontColor": {"solid": {"color": MUTED}}, "fontSize": 9}],
                "valueAxis": [{"gridlineColor": {"solid": {"color": LINE}}, "labelColor": {"solid": {"color": MUTED}}}],
                "categoryAxis": [{"labelColor": {"solid": {"color": MUTED}}}],
                "legend": [{"labelColor": {"solid": {"color": INK}}}],
                "labels": [{"color": {"solid": {"color": INK}}, "fontSize": 9}],
            }},
            "lineChart": {"*": {"lineStyles": [{"strokeWidth": 2}]}},
            "slicer": {"*": {"header": [{"show": False}]}},
            "page": {"*": {"background": [{"color": {"solid": {"color": BG}}, "transparency": 0}], "outspace": [{"color": {"solid": {"color": BG}}, "transparency": 0}]}},
        },
    }


def report_json() -> dict:
    return {
        "$schema": f"{SCHEMA}/item/report/definition/report/3.3.0/schema.json",
        "themeCollection": {
            "baseTheme": {"name": BASE_THEME, "reportVersionAtImport": VERSIONS, "type": "SharedResources"},
            "customTheme": {"name": "bic-tema.json", "reportVersionAtImport": VERSIONS, "type": "RegisteredResources"},
        },
        "objects": {"section": [{"properties": {"verticalAlignment": literal("Top")}}]},
        "resourcePackages": [
            {"name": "SharedResources", "type": "SharedResources", "items": [{"name": BASE_THEME, "path": f"BaseThemes/{BASE_THEME}.json", "type": "BaseTheme"}]},
            {"name": "RegisteredResources", "type": "RegisteredResources", "items": [{"name": "bic-tema.json", "path": "bic-tema.json", "type": "CustomTheme"}]},
        ],
        "settings": {
            "useStylableVisualContainerHeader": True, "exportDataMode": "AllowSummarized", "defaultDrillFilterOtherVisuals": True,
            "allowChangeFilterTypes": True, "useEnhancedTooltips": True, "useDefaultAggregateDisplayName": True,
        },
    }


def platform(kind: str, name: str) -> dict:
    return {"$schema": f"{SCHEMA}/gitIntegration/platformProperties/2.0.0/schema.json",
            "metadata": {"type": kind, "displayName": name}, "config": {"version": "2.0", "logicalId": tag("platform", kind, name)}}


# ----------------------------------------------------------------------------- escrita
def write(path: Path, content) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False, indent=2)
    path.write_text(text, encoding="utf-8", newline="\n")  # UTF-8 sem BOM, exigido pelo Power BI


def generate(out: Path, server: str, db: str, tz: str, base_theme: Path | None) -> None:
    name = "bic"
    rep, sm = out / f"{name}.Report", out / f"{name}.SemanticModel"
    if (out / "powerbi.gitignore").exists() is False:
        write(out / ".gitignore", "**/.pbi/\n")  # cache e preferências locais do Desktop
    write(out / f"{name}.pbip", {"version": "1.0", "artifacts": [{"report": {"path": f"{name}.Report"}}], "settings": {"enableAutoRecovery": True}})

    # modelo semântico (tabelas e páginas são recriadas do zero: o que saiu do gerador some do projeto)
    write(sm / "definition.pbism", {"$schema": f"{SCHEMA}/item/semanticModel/definitionProperties/1.0.0/schema.json", "version": "4.2", "settings": {}})
    write(sm / ".platform", platform("SemanticModel", name))
    write(sm / "definition" / "database.tmdl", "database\n\tcompatibilityLevel: 1606\n")
    write(sm / "definition" / "model.tmdl", model_tmdl())
    write(sm / "definition" / "expressions.tmdl", expressions_tmdl(server, db))
    write(sm / "definition" / "relationships.tmdl", relationships_tmdl())
    write(sm / "definition" / "cultures" / "pt-BR.tmdl", "cultureInfo pt-BR\n")
    shutil.rmtree(sm / "definition" / "tables", ignore_errors=True)
    for tname, view, columns, measures in TABLES:
        write(sm / "definition" / "tables" / f"{tname}.tmdl", table_tmdl(tname, view, columns, measures))
    for tname, tmdl in CALC_TABLES:
        write(sm / "definition" / "tables" / f"{tname}.tmdl", tmdl)

    # relatório
    write(rep / "definition.pbir", {"$schema": f"{SCHEMA}/item/report/definitionProperties/2.0.0/schema.json", "version": "4.0",
                                    "datasetReference": {"byPath": {"path": f"../{name}.SemanticModel"}}})
    write(rep / ".platform", platform("Report", name))
    write(rep / "StaticResources" / "RegisteredResources" / "bic-tema.json", theme())
    if base_theme and base_theme.exists():
        dest = rep / "StaticResources" / "SharedResources" / "BaseThemes" / f"{BASE_THEME}.json"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(base_theme, dest)
    d = rep / "definition"
    write(d / "version.json", {"$schema": f"{SCHEMA}/item/report/definition/versionMetadata/1.0.0/schema.json", "version": "2.0.0"})
    write(d / "report.json", report_json())

    pages = [
        page_charts(hex20("page", "charts"), tz, "PT10S"),
        page_now(hex20("page", "now"), tz, "PT10S"),
    ]
    shutil.rmtree(d / "pages", ignore_errors=True)
    write(d / "pages" / "pages.json", {"$schema": f"{SCHEMA}/item/report/definition/pagesMetadata/1.1.0/schema.json",
                                       "pageOrder": [p["name"] for p, _ in pages], "activePageName": pages[0][0]["name"]})
    for page, visuals in pages:
        write(d / "pages" / page["name"] / "page.json", page)
        for v in visuals:
            write(d / "pages" / page["name"] / "visuals" / v["name"] / "visual.json", v)
    print(f"projeto gerado em {out} ({len(TABLES) + len(CALC_TABLES)} tabelas, {len(pages)} páginas, {sum(len(v) for _, v in pages)} visuais)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=str(ROOT / "powerbi"))
    ap.add_argument("--server", default="localhost", help='SQL Server: "host", "host,1433" ou "host\\instancia"')
    ap.add_argument("--db", default="bic")
    ap.add_argument("--tz", default="America/Cuiaba", help="só para o texto do cabeçalho; o fuso real é a configuração display_timezone")
    ap.add_argument("--base-theme", default=None, help="arquivo JSON do tema base do Power BI a copiar (opcional)")
    a = ap.parse_args()
    generate(Path(a.out), a.server, a.db, a.tz, Path(a.base_theme) if a.base_theme else None)
